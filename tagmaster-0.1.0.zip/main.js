'use strict';

var obsidian = require('obsidian');

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise, SuppressedError, Symbol, Iterator */


function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

const TAGMASTER_VIEW_TYPE = 'tagmaster-view';
const TAG_WITH_BOUNDARY = /(?:^|[^a-zA-Z0-9_\-\/])#([a-zA-Z0-9_\-\/]+)(?:[^a-zA-Z0-9_\-\/]|$)/g;

class TagIndexer {
    constructor(vault, metadataCache, settings) {
        this.isIndexing = false;
        this.vault = vault;
        this.metadataCache = metadataCache;
        this.settings = settings;
        this.tagCatalog = new Map();
    }
    indexVault(onProgress) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.isIndexing) {
                console.warn('TagMaster: Indexing already in progress');
                return;
            }
            this.isIndexing = true;
            this.tagCatalog.clear();
            const files = this.vault.getMarkdownFiles();
            const total = files.length;
            for (let i = 0; i < total; i++) {
                const file = files[i];
                yield this.indexFile(file);
                if (onProgress) {
                    onProgress(i + 1, total);
                }
            }
            this.isIndexing = false;
        });
    }
    indexFile(file) {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const content = yield this.vault.cachedRead(file);
            const lines = content.split('\n');
            // Index frontmatter tags
            const frontmatter = (_a = this.metadataCache.getFileCache(file)) === null || _a === void 0 ? void 0 : _a.frontmatter;
            if (frontmatter === null || frontmatter === void 0 ? void 0 : frontmatter.tags) {
                this.indexFrontmatterTags(file, frontmatter.tags, content);
            }
            // Index inline tags
            lines.forEach((line, lineNumber) => {
                this.indexInlineTags(file, line, lineNumber);
            });
        });
    }
    indexFrontmatterTags(file, tags, content) {
        const tagArray = Array.isArray(tags) ? tags : [tags];
        const lines = content.split('\n');
        tagArray.forEach(tag => {
            const cleanTag = tag.startsWith('#') ? tag : `#${tag}`;
            // Find the line where this tag appears in frontmatter
            let lineNumber = 0;
            for (let i = 0; i < lines.length; i++) {
                if (lines[i].includes(tag)) {
                    lineNumber = i;
                    break;
                }
            }
            const occurrence = {
                file: file.path,
                line: lineNumber,
                context: lines[lineNumber] || '',
                isFrontmatter: true,
                startIndex: 0,
                endIndex: tag.length
            };
            this.addOccurrence(cleanTag, occurrence);
        });
    }
    indexInlineTags(file, line, lineNumber) {
        const matches = [...line.matchAll(TAG_WITH_BOUNDARY)];
        matches.forEach(match => {
            if (match[1]) {
                const tag = `#${match[1]}`;
                const occurrence = {
                    file: file.path,
                    line: lineNumber,
                    context: line,
                    isFrontmatter: false,
                    startIndex: match.index || 0,
                    endIndex: (match.index || 0) + tag.length
                };
                this.addOccurrence(tag, occurrence);
            }
        });
    }
    addOccurrence(tag, occurrence) {
        const normalizedTag = this.normalizeTag(tag);
        let tagInfo = this.tagCatalog.get(tag);
        if (!tagInfo) {
            tagInfo = {
                tag,
                normalizedTag,
                count: 0,
                occurrences: []
            };
            this.tagCatalog.set(tag, tagInfo);
        }
        tagInfo.occurrences.push(occurrence);
        tagInfo.count = tagInfo.occurrences.length;
    }
    normalizeTag(tag) {
        let normalized = tag.toLowerCase();
        if (this.settings.normalizationRules.removeDiacritics) {
            normalized = normalized.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        }
        if (this.settings.normalizationRules.underscoresToDashes) {
            normalized = normalized.replace(/_/g, '-');
        }
        if (this.settings.normalizationRules.stripPunctuation) {
            normalized = normalized.replace(/[^\w\s\-\/]/g, '');
        }
        return normalized;
    }
    getCatalog() {
        return this.tagCatalog;
    }
    getTagInfo(tag) {
        return this.tagCatalog.get(tag);
    }
    getAllTags() {
        return Array.from(this.tagCatalog.keys());
    }
    getTagCount() {
        return this.tagCatalog.size;
    }
    removeFileFromIndex(filePath) {
        for (const [tag, info] of this.tagCatalog.entries()) {
            info.occurrences = info.occurrences.filter(occ => occ.file !== filePath);
            info.count = info.occurrences.length;
            if (info.count === 0) {
                this.tagCatalog.delete(tag);
            }
        }
    }
}

class TagMasterSettingsTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
    }
    display() {
        const { containerEl } = this;
        containerEl.empty();
        containerEl.createEl('h2', { text: 'TagMaster Settings' });
        // Normalization Rules
        containerEl.createEl('h3', { text: 'Normalization Rules' });
        new obsidian.Setting(containerEl)
            .setName('Case folding')
            .setDesc('Convert tags to lowercase for comparison')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.normalizationRules.caseFolding)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.normalizationRules.caseFolding = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Remove diacritics')
            .setDesc('Remove accents and diacritical marks (é → e)')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.normalizationRules.removeDiacritics)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.normalizationRules.removeDiacritics = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Underscores to dashes')
            .setDesc('Treat underscores as dashes (#tag_name → #tag-name)')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.normalizationRules.underscoresToDashes)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.normalizationRules.underscoresToDashes = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Strip punctuation')
            .setDesc('Remove punctuation from tags')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.normalizationRules.stripPunctuation)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.normalizationRules.stripPunctuation = value;
            yield this.plugin.saveSettings();
        })));
        // Similarity Thresholds
        containerEl.createEl('h3', { text: 'Similarity Thresholds (0-1)' });
        new obsidian.Setting(containerEl)
            .setName('Levenshtein threshold')
            .setDesc('Minimum similarity for Levenshtein distance (higher = more strict)')
            .addSlider(slider => slider
            .setLimits(0, 1, 0.05)
            .setValue(this.plugin.settings.similarityThresholds.levenshtein)
            .setDynamicTooltip()
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.similarityThresholds.levenshtein = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Jaro-Winkler threshold')
            .setDesc('Minimum similarity for Jaro-Winkler distance')
            .addSlider(slider => slider
            .setLimits(0, 1, 0.05)
            .setValue(this.plugin.settings.similarityThresholds.jaroWinkler)
            .setDynamicTooltip()
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.similarityThresholds.jaroWinkler = value;
            yield this.plugin.saveSettings();
        })));
        // Preview Settings
        containerEl.createEl('h3', { text: 'Preview Settings' });
        new obsidian.Setting(containerEl)
            .setName('Max preview examples')
            .setDesc('Number of examples to show in preview')
            .addText(text => text
            .setValue(String(this.plugin.settings.previewSettings.maxExamples))
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            const num = parseInt(value);
            if (!isNaN(num) && num > 0) {
                this.plugin.settings.previewSettings.maxExamples = num;
                yield this.plugin.saveSettings();
            }
        })));
        // Safety
        containerEl.createEl('h3', { text: 'Safety' });
        new obsidian.Setting(containerEl)
            .setName('Safe mode')
            .setDesc('Require dry-run before applying changes')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.safeMode)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.safeMode = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Enable undo')
            .setDesc('Keep backup snapshots for undo operations')
            .addToggle(toggle => toggle
            .setValue(this.plugin.settings.enableUndo)
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            this.plugin.settings.enableUndo = value;
            yield this.plugin.saveSettings();
        })));
        new obsidian.Setting(containerEl)
            .setName('Max backups')
            .setDesc('Maximum number of backup snapshots to keep')
            .addText(text => text
            .setValue(String(this.plugin.settings.maxBackups))
            .onChange((value) => __awaiter(this, void 0, void 0, function* () {
            const num = parseInt(value);
            if (!isNaN(num) && num > 0) {
                this.plugin.settings.maxBackups = num;
                yield this.plugin.saveSettings();
            }
        })));
    }
}

class TagMasterView extends obsidian.ItemView {
    constructor(leaf, plugin) {
        super(leaf);
        this.plugin = plugin;
    }
    getViewType() {
        return TAGMASTER_VIEW_TYPE;
    }
    getDisplayText() {
        return 'TagMaster';
    }
    getIcon() {
        return 'tags';
    }
    onOpen() {
        return __awaiter(this, void 0, void 0, function* () {
            const container = this.containerEl.children[1];
            container.empty();
            container.addClass('tagmaster-view');
            // Header
            const header = container.createEl('div', { cls: 'tagmaster-header' });
            header.createEl('h3', { text: 'Tag Catalog' });
            const scanButton = header.createEl('button', { text: 'Scan Vault', cls: 'mod-cta' });
            scanButton.addEventListener('click', () => __awaiter(this, void 0, void 0, function* () {
                scanButton.disabled = true;
                scanButton.textContent = 'Scanning...';
                yield this.plugin.indexer.indexVault((current, total) => {
                    scanButton.textContent = `Scanning ${current}/${total}`;
                });
                scanButton.textContent = 'Scan Vault';
                scanButton.disabled = false;
                this.renderTagList();
            }));
            // Stats
            const stats = container.createEl('div', { cls: 'tagmaster-stats' });
            this.renderStats(stats);
            // Tag list
            const listContainer = container.createEl('div', { cls: 'tagmaster-list' });
            this.renderTagList(listContainer);
        });
    }
    renderStats(container) {
        container.empty();
        const tagCount = this.plugin.indexer.getTagCount();
        container.createEl('p', { text: `Total tags: ${tagCount}` });
    }
    renderTagList(container) {
        const listEl = container || this.containerEl.querySelector('.tagmaster-list');
        if (!listEl)
            return;
        listEl.empty();
        const catalog = this.plugin.indexer.getCatalog();
        const sortedTags = Array.from(catalog.entries())
            .sort((a, b) => b[1].count - a[1].count);
        sortedTags.forEach(([tag, info]) => {
            const tagItem = listEl.createEl('div', { cls: 'tagmaster-tag-item' });
            tagItem.createEl('span', {
                cls: 'tagmaster-tag-name',
                text: tag
            });
            tagItem.createEl('span', {
                cls: 'tagmaster-tag-count',
                text: `${info.count}`
            });
            tagItem.addEventListener('click', () => {
                this.showTagDetails(tag, info);
            });
        });
        // Update stats
        const statsEl = this.containerEl.querySelector('.tagmaster-stats');
        if (statsEl) {
            this.renderStats(statsEl);
        }
    }
    showTagDetails(tag, info) {
        console.log('Tag details:', tag, info);
        // TODO: Implement modal with tag details and actions
    }
    onClose() {
        return __awaiter(this, void 0, void 0, function* () {
            // Cleanup
        });
    }
}

const DEFAULT_SETTINGS = {
    normalizationRules: {
        caseFolding: true,
        removeDiacritics: true,
        underscoresToDashes: true,
        stripPunctuation: true
    },
    similarityThresholds: {
        levenshtein: 0.8,
        jaroWinkler: 0.85,
        tokenOverlap: 0.7
    },
    previewSettings: {
        maxExamples: 5,
        contextLines: 2
    },
    safeMode: true,
    enableUndo: true,
    maxBackups: 10,
    enableEmbeddings: false
};

class TagMasterPlugin extends obsidian.Plugin {
    onload() {
        return __awaiter(this, void 0, void 0, function* () {
            console.log('Loading TagMaster Plugin');
            yield this.loadSettings();
            this.indexer = new TagIndexer(this.app.vault, this.app.metadataCache, this.settings);
            // Register view
            this.registerView(TAGMASTER_VIEW_TYPE, (leaf) => new TagMasterView(leaf, this));
            // Add ribbon icon
            this.addRibbonIcon('tags', 'Open TagMaster', () => {
                this.activateView();
            });
            // Register commands
            this.addCommand({
                id: 'scan-vault',
                name: 'Scan vault for tags',
                callback: () => __awaiter(this, void 0, void 0, function* () {
                    yield this.indexer.indexVault((current, total) => {
                        console.log(`Indexing: ${current}/${total}`);
                    });
                    console.log(`TagMaster: Indexed ${this.indexer.getTagCount()} tags`);
                })
            });
            this.addCommand({
                id: 'open-tagmaster',
                name: 'Open TagMaster panel',
                callback: () => {
                    this.activateView();
                }
            });
            // Settings tab
            this.addSettingTab(new TagMasterSettingsTab(this.app, this));
            // File event listeners for incremental indexing
            this.registerEvent(this.app.vault.on('modify', (file) => {
                if (file instanceof obsidian.TFile && file.extension === 'md') {
                    this.indexer.indexFile(file);
                }
            }));
            this.registerEvent(this.app.vault.on('delete', (file) => {
                if (file instanceof obsidian.TFile && file.extension === 'md') {
                    this.indexer.removeFileFromIndex(file.path);
                }
            }));
            // Initial scan
            yield this.indexer.indexVault();
        });
    }
    activateView() {
        return __awaiter(this, void 0, void 0, function* () {
            this.app.workspace.detachLeavesOfType(TAGMASTER_VIEW_TYPE);
            const leaf = this.app.workspace.getRightLeaf(false);
            if (leaf) {
                yield leaf.setViewState({
                    type: TAGMASTER_VIEW_TYPE,
                    active: true
                });
                this.app.workspace.revealLeaf(leaf);
            }
        });
    }
    onunload() {
        console.log('Unloading TagMaster Plugin');
        this.app.workspace.detachLeavesOfType(TAGMASTER_VIEW_TYPE);
    }
    loadSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
        });
    }
    saveSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.saveData(this.settings);
        });
    }
}

module.exports = TagMasterPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsibm9kZV9tb2R1bGVzL3RzbGliL3RzbGliLmVzNi5qcyIsInNyYy9jb25zdGFudHMudHMiLCJzcmMvY29yZS9UYWdJbmRleGVyLnRzIiwic3JjL3VpL1NldHRpbmdzVGFiLnRzIiwic3JjL3VpL1RhZ01hc3RlclZpZXcudHMiLCJzcmMvdHlwZXMudHMiLCJtYWluLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uXHJcblxyXG5QZXJtaXNzaW9uIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBhbmQvb3IgZGlzdHJpYnV0ZSB0aGlzIHNvZnR3YXJlIGZvciBhbnlcclxucHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLlxyXG5cclxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiBBTkQgVEhFIEFVVEhPUiBESVNDTEFJTVMgQUxMIFdBUlJBTlRJRVMgV0lUSFxyXG5SRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFlcclxuQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUiBBTlkgU1BFQ0lBTCwgRElSRUNULFxyXG5JTkRJUkVDVCwgT1IgQ09OU0VRVUVOVElBTCBEQU1BR0VTIE9SIEFOWSBEQU1BR0VTIFdIQVRTT0VWRVIgUkVTVUxUSU5HIEZST01cclxuTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1JcclxuT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUlxyXG5QRVJGT1JNQU5DRSBPRiBUSElTIFNPRlRXQVJFLlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xyXG4vKiBnbG9iYWwgUmVmbGVjdCwgUHJvbWlzZSwgU3VwcHJlc3NlZEVycm9yLCBTeW1ib2wsIEl0ZXJhdG9yICovXHJcblxyXG52YXIgZXh0ZW5kU3RhdGljcyA9IGZ1bmN0aW9uKGQsIGIpIHtcclxuICAgIGV4dGVuZFN0YXRpY3MgPSBPYmplY3Quc2V0UHJvdG90eXBlT2YgfHxcclxuICAgICAgICAoeyBfX3Byb3RvX186IFtdIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikgeyBkLl9fcHJvdG9fXyA9IGI7IH0pIHx8XHJcbiAgICAgICAgZnVuY3Rpb24gKGQsIGIpIHsgZm9yICh2YXIgcCBpbiBiKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGIsIHApKSBkW3BdID0gYltwXTsgfTtcclxuICAgIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XHJcbiAgICBpZiAodHlwZW9mIGIgIT09IFwiZnVuY3Rpb25cIiAmJiBiICE9PSBudWxsKVxyXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcclxuICAgIGV4dGVuZFN0YXRpY3MoZCwgYik7XHJcbiAgICBmdW5jdGlvbiBfXygpIHsgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7IH1cclxuICAgIGQucHJvdG90eXBlID0gYiA9PT0gbnVsbCA/IE9iamVjdC5jcmVhdGUoYikgOiAoX18ucHJvdG90eXBlID0gYi5wcm90b3R5cGUsIG5ldyBfXygpKTtcclxufVxyXG5cclxuZXhwb3J0IHZhciBfX2Fzc2lnbiA9IGZ1bmN0aW9uKCkge1xyXG4gICAgX19hc3NpZ24gPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uIF9fYXNzaWduKHQpIHtcclxuICAgICAgICBmb3IgKHZhciBzLCBpID0gMSwgbiA9IGFyZ3VtZW50cy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcclxuICAgICAgICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcclxuICAgICAgICAgICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApKSB0W3BdID0gc1twXTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHQ7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVzdChzLCBlKSB7XHJcbiAgICB2YXIgdCA9IHt9O1xyXG4gICAgZm9yICh2YXIgcCBpbiBzKSBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHMsIHApICYmIGUuaW5kZXhPZihwKSA8IDApXHJcbiAgICAgICAgdFtwXSA9IHNbcF07XHJcbiAgICBpZiAocyAhPSBudWxsICYmIHR5cGVvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzID09PSBcImZ1bmN0aW9uXCIpXHJcbiAgICAgICAgZm9yICh2YXIgaSA9IDAsIHAgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHMpOyBpIDwgcC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAoZS5pbmRleE9mKHBbaV0pIDwgMCAmJiBPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwocywgcFtpXSkpXHJcbiAgICAgICAgICAgICAgICB0W3BbaV1dID0gc1twW2ldXTtcclxuICAgICAgICB9XHJcbiAgICByZXR1cm4gdDtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpIHtcclxuICAgIHZhciBjID0gYXJndW1lbnRzLmxlbmd0aCwgciA9IGMgPCAzID8gdGFyZ2V0IDogZGVzYyA9PT0gbnVsbCA/IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHRhcmdldCwga2V5KSA6IGRlc2MsIGQ7XHJcbiAgICBpZiAodHlwZW9mIFJlZmxlY3QgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIFJlZmxlY3QuZGVjb3JhdGUgPT09IFwiZnVuY3Rpb25cIikgciA9IFJlZmxlY3QuZGVjb3JhdGUoZGVjb3JhdG9ycywgdGFyZ2V0LCBrZXksIGRlc2MpO1xyXG4gICAgZWxzZSBmb3IgKHZhciBpID0gZGVjb3JhdG9ycy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkgaWYgKGQgPSBkZWNvcmF0b3JzW2ldKSByID0gKGMgPCAzID8gZChyKSA6IGMgPiAzID8gZCh0YXJnZXQsIGtleSwgcikgOiBkKHRhcmdldCwga2V5KSkgfHwgcjtcclxuICAgIHJldHVybiBjID4gMyAmJiByICYmIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGtleSwgciksIHI7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3BhcmFtKHBhcmFtSW5kZXgsIGRlY29yYXRvcikge1xyXG4gICAgcmV0dXJuIGZ1bmN0aW9uICh0YXJnZXQsIGtleSkgeyBkZWNvcmF0b3IodGFyZ2V0LCBrZXksIHBhcmFtSW5kZXgpOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2VzRGVjb3JhdGUoY3RvciwgZGVzY3JpcHRvckluLCBkZWNvcmF0b3JzLCBjb250ZXh0SW4sIGluaXRpYWxpemVycywgZXh0cmFJbml0aWFsaXplcnMpIHtcclxuICAgIGZ1bmN0aW9uIGFjY2VwdChmKSB7IGlmIChmICE9PSB2b2lkIDAgJiYgdHlwZW9mIGYgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkZ1bmN0aW9uIGV4cGVjdGVkXCIpOyByZXR1cm4gZjsgfVxyXG4gICAgdmFyIGtpbmQgPSBjb250ZXh0SW4ua2luZCwga2V5ID0ga2luZCA9PT0gXCJnZXR0ZXJcIiA/IFwiZ2V0XCIgOiBraW5kID09PSBcInNldHRlclwiID8gXCJzZXRcIiA6IFwidmFsdWVcIjtcclxuICAgIHZhciB0YXJnZXQgPSAhZGVzY3JpcHRvckluICYmIGN0b3IgPyBjb250ZXh0SW5bXCJzdGF0aWNcIl0gPyBjdG9yIDogY3Rvci5wcm90b3R5cGUgOiBudWxsO1xyXG4gICAgdmFyIGRlc2NyaXB0b3IgPSBkZXNjcmlwdG9ySW4gfHwgKHRhcmdldCA/IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodGFyZ2V0LCBjb250ZXh0SW4ubmFtZSkgOiB7fSk7XHJcbiAgICB2YXIgXywgZG9uZSA9IGZhbHNlO1xyXG4gICAgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcclxuICAgICAgICB2YXIgY29udGV4dCA9IHt9O1xyXG4gICAgICAgIGZvciAodmFyIHAgaW4gY29udGV4dEluKSBjb250ZXh0W3BdID0gcCA9PT0gXCJhY2Nlc3NcIiA/IHt9IDogY29udGV4dEluW3BdO1xyXG4gICAgICAgIGZvciAodmFyIHAgaW4gY29udGV4dEluLmFjY2VzcykgY29udGV4dC5hY2Nlc3NbcF0gPSBjb250ZXh0SW4uYWNjZXNzW3BdO1xyXG4gICAgICAgIGNvbnRleHQuYWRkSW5pdGlhbGl6ZXIgPSBmdW5jdGlvbiAoZikgeyBpZiAoZG9uZSkgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBhZGQgaW5pdGlhbGl6ZXJzIGFmdGVyIGRlY29yYXRpb24gaGFzIGNvbXBsZXRlZFwiKTsgZXh0cmFJbml0aWFsaXplcnMucHVzaChhY2NlcHQoZiB8fCBudWxsKSk7IH07XHJcbiAgICAgICAgdmFyIHJlc3VsdCA9ICgwLCBkZWNvcmF0b3JzW2ldKShraW5kID09PSBcImFjY2Vzc29yXCIgPyB7IGdldDogZGVzY3JpcHRvci5nZXQsIHNldDogZGVzY3JpcHRvci5zZXQgfSA6IGRlc2NyaXB0b3Jba2V5XSwgY29udGV4dCk7XHJcbiAgICAgICAgaWYgKGtpbmQgPT09IFwiYWNjZXNzb3JcIikge1xyXG4gICAgICAgICAgICBpZiAocmVzdWx0ID09PSB2b2lkIDApIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICBpZiAocmVzdWx0ID09PSBudWxsIHx8IHR5cGVvZiByZXN1bHQgIT09IFwib2JqZWN0XCIpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJPYmplY3QgZXhwZWN0ZWRcIik7XHJcbiAgICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5nZXQpKSBkZXNjcmlwdG9yLmdldCA9IF87XHJcbiAgICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5zZXQpKSBkZXNjcmlwdG9yLnNldCA9IF87XHJcbiAgICAgICAgICAgIGlmIChfID0gYWNjZXB0KHJlc3VsdC5pbml0KSkgaW5pdGlhbGl6ZXJzLnVuc2hpZnQoXyk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGVsc2UgaWYgKF8gPSBhY2NlcHQocmVzdWx0KSkge1xyXG4gICAgICAgICAgICBpZiAoa2luZCA9PT0gXCJmaWVsZFwiKSBpbml0aWFsaXplcnMudW5zaGlmdChfKTtcclxuICAgICAgICAgICAgZWxzZSBkZXNjcmlwdG9yW2tleV0gPSBfO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0YXJnZXQpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGNvbnRleHRJbi5uYW1lLCBkZXNjcmlwdG9yKTtcclxuICAgIGRvbmUgPSB0cnVlO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcnVuSW5pdGlhbGl6ZXJzKHRoaXNBcmcsIGluaXRpYWxpemVycywgdmFsdWUpIHtcclxuICAgIHZhciB1c2VWYWx1ZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAyO1xyXG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBpbml0aWFsaXplcnMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICB2YWx1ZSA9IHVzZVZhbHVlID8gaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZywgdmFsdWUpIDogaW5pdGlhbGl6ZXJzW2ldLmNhbGwodGhpc0FyZyk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdXNlVmFsdWUgPyB2YWx1ZSA6IHZvaWQgMDtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Byb3BLZXkoeCkge1xyXG4gICAgcmV0dXJuIHR5cGVvZiB4ID09PSBcInN5bWJvbFwiID8geCA6IFwiXCIuY29uY2F0KHgpO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fc2V0RnVuY3Rpb25OYW1lKGYsIG5hbWUsIHByZWZpeCkge1xyXG4gICAgaWYgKHR5cGVvZiBuYW1lID09PSBcInN5bWJvbFwiKSBuYW1lID0gbmFtZS5kZXNjcmlwdGlvbiA/IFwiW1wiLmNvbmNhdChuYW1lLmRlc2NyaXB0aW9uLCBcIl1cIikgOiBcIlwiO1xyXG4gICAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShmLCBcIm5hbWVcIiwgeyBjb25maWd1cmFibGU6IHRydWUsIHZhbHVlOiBwcmVmaXggPyBcIlwiLmNvbmNhdChwcmVmaXgsIFwiIFwiLCBuYW1lKSA6IG5hbWUgfSk7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0Lm1ldGFkYXRhID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBSZWZsZWN0Lm1ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXRlcih0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2dlbmVyYXRvcih0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnID0gT2JqZWN0LmNyZWF0ZSgodHlwZW9mIEl0ZXJhdG9yID09PSBcImZ1bmN0aW9uXCIgPyBJdGVyYXRvciA6IE9iamVjdCkucHJvdG90eXBlKTtcclxuICAgIHJldHVybiBnLm5leHQgPSB2ZXJiKDApLCBnW1widGhyb3dcIl0gPSB2ZXJiKDEpLCBnW1wicmV0dXJuXCJdID0gdmVyYigyKSwgdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIChnW1N5bWJvbC5pdGVyYXRvcl0gPSBmdW5jdGlvbigpIHsgcmV0dXJuIHRoaXM7IH0pLCBnO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IHJldHVybiBmdW5jdGlvbiAodikgeyByZXR1cm4gc3RlcChbbiwgdl0pOyB9OyB9XHJcbiAgICBmdW5jdGlvbiBzdGVwKG9wKSB7XHJcbiAgICAgICAgaWYgKGYpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJHZW5lcmF0b3IgaXMgYWxyZWFkeSBleGVjdXRpbmcuXCIpO1xyXG4gICAgICAgIHdoaWxlIChnICYmIChnID0gMCwgb3BbMF0gJiYgKF8gPSAwKSksIF8pIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChmID0gMSwgeSAmJiAodCA9IG9wWzBdICYgMiA/IHlbXCJyZXR1cm5cIl0gOiBvcFswXSA/IHlbXCJ0aHJvd1wiXSB8fCAoKHQgPSB5W1wicmV0dXJuXCJdKSAmJiB0LmNhbGwoeSksIDApIDogeS5uZXh0KSAmJiAhKHQgPSB0LmNhbGwoeSwgb3BbMV0pKS5kb25lKSByZXR1cm4gdDtcclxuICAgICAgICAgICAgaWYgKHkgPSAwLCB0KSBvcCA9IFtvcFswXSAmIDIsIHQudmFsdWVdO1xyXG4gICAgICAgICAgICBzd2l0Y2ggKG9wWzBdKSB7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDA6IGNhc2UgMTogdCA9IG9wOyBicmVhaztcclxuICAgICAgICAgICAgICAgIGNhc2UgNDogXy5sYWJlbCsrOyByZXR1cm4geyB2YWx1ZTogb3BbMV0sIGRvbmU6IGZhbHNlIH07XHJcbiAgICAgICAgICAgICAgICBjYXNlIDU6IF8ubGFiZWwrKzsgeSA9IG9wWzFdOyBvcCA9IFswXTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBjYXNlIDc6IG9wID0gXy5vcHMucG9wKCk7IF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgICAgIGlmICghKHQgPSBfLnRyeXMsIHQgPSB0Lmxlbmd0aCA+IDAgJiYgdFt0Lmxlbmd0aCAtIDFdKSAmJiAob3BbMF0gPT09IDYgfHwgb3BbMF0gPT09IDIpKSB7IF8gPSAwOyBjb250aW51ZTsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmIChvcFswXSA9PT0gMyAmJiAoIXQgfHwgKG9wWzFdID4gdFswXSAmJiBvcFsxXSA8IHRbM10pKSkgeyBfLmxhYmVsID0gb3BbMV07IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSA2ICYmIF8ubGFiZWwgPCB0WzFdKSB7IF8ubGFiZWwgPSB0WzFdOyB0ID0gb3A7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHQgJiYgXy5sYWJlbCA8IHRbMl0pIHsgXy5sYWJlbCA9IHRbMl07IF8ub3BzLnB1c2gob3ApOyBicmVhazsgfVxyXG4gICAgICAgICAgICAgICAgICAgIGlmICh0WzJdKSBfLm9wcy5wb3AoKTtcclxuICAgICAgICAgICAgICAgICAgICBfLnRyeXMucG9wKCk7IGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIG9wID0gYm9keS5jYWxsKHRoaXNBcmcsIF8pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHsgb3AgPSBbNiwgZV07IHkgPSAwOyB9IGZpbmFsbHkgeyBmID0gdCA9IDA7IH1cclxuICAgICAgICBpZiAob3BbMF0gJiA1KSB0aHJvdyBvcFsxXTsgcmV0dXJuIHsgdmFsdWU6IG9wWzBdID8gb3BbMV0gOiB2b2lkIDAsIGRvbmU6IHRydWUgfTtcclxuICAgIH1cclxufVxyXG5cclxuZXhwb3J0IHZhciBfX2NyZWF0ZUJpbmRpbmcgPSBPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XHJcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xyXG4gICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xyXG4gICAgaWYgKCFkZXNjIHx8IChcImdldFwiIGluIGRlc2MgPyAhbS5fX2VzTW9kdWxlIDogZGVzYy53cml0YWJsZSB8fCBkZXNjLmNvbmZpZ3VyYWJsZSkpIHtcclxuICAgICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xyXG4gICAgfVxyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcclxufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcclxuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XHJcbiAgICBvW2syXSA9IG1ba107XHJcbn0pO1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fZXhwb3J0U3RhcihtLCBvKSB7XHJcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG8sIHApKSBfX2NyZWF0ZUJpbmRpbmcobywgbSwgcCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3ZhbHVlcyhvKSB7XHJcbiAgICB2YXIgcyA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBTeW1ib2wuaXRlcmF0b3IsIG0gPSBzICYmIG9bc10sIGkgPSAwO1xyXG4gICAgaWYgKG0pIHJldHVybiBtLmNhbGwobyk7XHJcbiAgICBpZiAobyAmJiB0eXBlb2Ygby5sZW5ndGggPT09IFwibnVtYmVyXCIpIHJldHVybiB7XHJcbiAgICAgICAgbmV4dDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgICAgICBpZiAobyAmJiBpID49IG8ubGVuZ3RoKSBvID0gdm9pZCAwO1xyXG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogbyAmJiBvW2krK10sIGRvbmU6ICFvIH07XHJcbiAgICAgICAgfVxyXG4gICAgfTtcclxuICAgIHRocm93IG5ldyBUeXBlRXJyb3IocyA/IFwiT2JqZWN0IGlzIG5vdCBpdGVyYWJsZS5cIiA6IFwiU3ltYm9sLml0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fcmVhZChvLCBuKSB7XHJcbiAgICB2YXIgbSA9IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBvW1N5bWJvbC5pdGVyYXRvcl07XHJcbiAgICBpZiAoIW0pIHJldHVybiBvO1xyXG4gICAgdmFyIGkgPSBtLmNhbGwobyksIHIsIGFyID0gW10sIGU7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlICgobiA9PT0gdm9pZCAwIHx8IG4tLSA+IDApICYmICEociA9IGkubmV4dCgpKS5kb25lKSBhci5wdXNoKHIudmFsdWUpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2ggKGVycm9yKSB7IGUgPSB7IGVycm9yOiBlcnJvciB9OyB9XHJcbiAgICBmaW5hbGx5IHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBpZiAociAmJiAhci5kb25lICYmIChtID0gaVtcInJldHVyblwiXSkpIG0uY2FsbChpKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZmluYWxseSB7IGlmIChlKSB0aHJvdyBlLmVycm9yOyB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbi8qKiBAZGVwcmVjYXRlZCAqL1xyXG5leHBvcnQgZnVuY3Rpb24gX19zcHJlYWQoKSB7XHJcbiAgICBmb3IgKHZhciBhciA9IFtdLCBpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKylcclxuICAgICAgICBhciA9IGFyLmNvbmNhdChfX3JlYWQoYXJndW1lbnRzW2ldKSk7XHJcbiAgICByZXR1cm4gYXI7XHJcbn1cclxuXHJcbi8qKiBAZGVwcmVjYXRlZCAqL1xyXG5leHBvcnQgZnVuY3Rpb24gX19zcHJlYWRBcnJheXMoKSB7XHJcbiAgICBmb3IgKHZhciBzID0gMCwgaSA9IDAsIGlsID0gYXJndW1lbnRzLmxlbmd0aDsgaSA8IGlsOyBpKyspIHMgKz0gYXJndW1lbnRzW2ldLmxlbmd0aDtcclxuICAgIGZvciAodmFyIHIgPSBBcnJheShzKSwgayA9IDAsIGkgPSAwOyBpIDwgaWw7IGkrKylcclxuICAgICAgICBmb3IgKHZhciBhID0gYXJndW1lbnRzW2ldLCBqID0gMCwgamwgPSBhLmxlbmd0aDsgaiA8IGpsOyBqKyssIGsrKylcclxuICAgICAgICAgICAgcltrXSA9IGFbal07XHJcbiAgICByZXR1cm4gcjtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fc3ByZWFkQXJyYXkodG8sIGZyb20sIHBhY2spIHtcclxuICAgIGlmIChwYWNrIHx8IGFyZ3VtZW50cy5sZW5ndGggPT09IDIpIGZvciAodmFyIGkgPSAwLCBsID0gZnJvbS5sZW5ndGgsIGFyOyBpIDwgbDsgaSsrKSB7XHJcbiAgICAgICAgaWYgKGFyIHx8ICEoaSBpbiBmcm9tKSkge1xyXG4gICAgICAgICAgICBpZiAoIWFyKSBhciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20sIDAsIGkpO1xyXG4gICAgICAgICAgICBhcltpXSA9IGZyb21baV07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRvLmNvbmNhdChhciB8fCBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChmcm9tKSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2F3YWl0KHYpIHtcclxuICAgIHJldHVybiB0aGlzIGluc3RhbmNlb2YgX19hd2FpdCA/ICh0aGlzLnYgPSB2LCB0aGlzKSA6IG5ldyBfX2F3YWl0KHYpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0dlbmVyYXRvcih0aGlzQXJnLCBfYXJndW1lbnRzLCBnZW5lcmF0b3IpIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgZyA9IGdlbmVyYXRvci5hcHBseSh0aGlzQXJnLCBfYXJndW1lbnRzIHx8IFtdKSwgaSwgcSA9IFtdO1xyXG4gICAgcmV0dXJuIGkgPSBPYmplY3QuY3JlYXRlKCh0eXBlb2YgQXN5bmNJdGVyYXRvciA9PT0gXCJmdW5jdGlvblwiID8gQXN5bmNJdGVyYXRvciA6IE9iamVjdCkucHJvdG90eXBlKSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiKSwgdmVyYihcInJldHVyblwiLCBhd2FpdFJldHVybiksIGlbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID0gZnVuY3Rpb24gKCkgeyByZXR1cm4gdGhpczsgfSwgaTtcclxuICAgIGZ1bmN0aW9uIGF3YWl0UmV0dXJuKGYpIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBQcm9taXNlLnJlc29sdmUodikudGhlbihmLCByZWplY3QpOyB9OyB9XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaWYgKGdbbl0pIHsgaVtuXSA9IGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAoYSwgYikgeyBxLnB1c2goW24sIHYsIGEsIGJdKSA+IDEgfHwgcmVzdW1lKG4sIHYpOyB9KTsgfTsgaWYgKGYpIGlbbl0gPSBmKGlbbl0pOyB9IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBmYWxzZSB9IDogZiA/IGYodikgOiB2OyB9IDogZjsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY1ZhbHVlcyhvKSB7XHJcbiAgICBpZiAoIVN5bWJvbC5hc3luY0l0ZXJhdG9yKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3ltYm9sLmFzeW5jSXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xyXG4gICAgdmFyIG0gPSBvW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSwgaTtcclxuICAgIHJldHVybiBtID8gbS5jYWxsKG8pIDogKG8gPSB0eXBlb2YgX192YWx1ZXMgPT09IFwiZnVuY3Rpb25cIiA/IF9fdmFsdWVzKG8pIDogb1tTeW1ib2wuaXRlcmF0b3JdKCksIGkgPSB7fSwgdmVyYihcIm5leHRcIiksIHZlcmIoXCJ0aHJvd1wiKSwgdmVyYihcInJldHVyblwiKSwgaVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gPSBmdW5jdGlvbiAoKSB7IHJldHVybiB0aGlzOyB9LCBpKTtcclxuICAgIGZ1bmN0aW9uIHZlcmIobikgeyBpW25dID0gb1tuXSAmJiBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkgeyB2ID0gb1tuXSh2KSwgc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgdi5kb25lLCB2LnZhbHVlKTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHNldHRsZShyZXNvbHZlLCByZWplY3QsIGQsIHYpIHsgUHJvbWlzZS5yZXNvbHZlKHYpLnRoZW4oZnVuY3Rpb24odikgeyByZXNvbHZlKHsgdmFsdWU6IHYsIGRvbmU6IGQgfSk7IH0sIHJlamVjdCk7IH1cclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fbWFrZVRlbXBsYXRlT2JqZWN0KGNvb2tlZCwgcmF3KSB7XHJcbiAgICBpZiAoT2JqZWN0LmRlZmluZVByb3BlcnR5KSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb29rZWQsIFwicmF3XCIsIHsgdmFsdWU6IHJhdyB9KTsgfSBlbHNlIHsgY29va2VkLnJhdyA9IHJhdzsgfVxyXG4gICAgcmV0dXJuIGNvb2tlZDtcclxufTtcclxuXHJcbnZhciBfX3NldE1vZHVsZURlZmF1bHQgPSBPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIHYpIHtcclxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBcImRlZmF1bHRcIiwgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdiB9KTtcclxufSkgOiBmdW5jdGlvbihvLCB2KSB7XHJcbiAgICBvW1wiZGVmYXVsdFwiXSA9IHY7XHJcbn07XHJcblxyXG52YXIgb3duS2V5cyA9IGZ1bmN0aW9uKG8pIHtcclxuICAgIG93bktleXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyB8fCBmdW5jdGlvbiAobykge1xyXG4gICAgICAgIHZhciBhciA9IFtdO1xyXG4gICAgICAgIGZvciAodmFyIGsgaW4gbykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvLCBrKSkgYXJbYXIubGVuZ3RoXSA9IGs7XHJcbiAgICAgICAgcmV0dXJuIGFyO1xyXG4gICAgfTtcclxuICAgIHJldHVybiBvd25LZXlzKG8pO1xyXG59O1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9faW1wb3J0U3Rhcihtb2QpIHtcclxuICAgIGlmIChtb2QgJiYgbW9kLl9fZXNNb2R1bGUpIHJldHVybiBtb2Q7XHJcbiAgICB2YXIgcmVzdWx0ID0ge307XHJcbiAgICBpZiAobW9kICE9IG51bGwpIGZvciAodmFyIGsgPSBvd25LZXlzKG1vZCksIGkgPSAwOyBpIDwgay5sZW5ndGg7IGkrKykgaWYgKGtbaV0gIT09IFwiZGVmYXVsdFwiKSBfX2NyZWF0ZUJpbmRpbmcocmVzdWx0LCBtb2QsIGtbaV0pO1xyXG4gICAgX19zZXRNb2R1bGVEZWZhdWx0KHJlc3VsdCwgbW9kKTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydERlZmF1bHQobW9kKSB7XHJcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IGRlZmF1bHQ6IG1vZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEdldChyZWNlaXZlciwgc3RhdGUsIGtpbmQsIGYpIHtcclxuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcclxuICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHJlYWQgcHJpdmF0ZSBtZW1iZXIgZnJvbSBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xyXG4gICAgcmV0dXJuIGtpbmQgPT09IFwibVwiID8gZiA6IGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyKSA6IGYgPyBmLnZhbHVlIDogc3RhdGUuZ2V0KHJlY2VpdmVyKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fY2xhc3NQcml2YXRlRmllbGRTZXQocmVjZWl2ZXIsIHN0YXRlLCB2YWx1ZSwga2luZCwgZikge1xyXG4gICAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xyXG4gICAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgc2V0dGVyXCIpO1xyXG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3Qgd3JpdGUgcHJpdmF0ZSBtZW1iZXIgdG8gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcclxuICAgIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEluKHN0YXRlLCByZWNlaXZlcikge1xyXG4gICAgaWYgKHJlY2VpdmVyID09PSBudWxsIHx8ICh0eXBlb2YgcmVjZWl2ZXIgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHJlY2VpdmVyICE9PSBcImZ1bmN0aW9uXCIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHVzZSAnaW4nIG9wZXJhdG9yIG9uIG5vbi1vYmplY3RcIik7XHJcbiAgICByZXR1cm4gdHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciA9PT0gc3RhdGUgOiBzdGF0ZS5oYXMocmVjZWl2ZXIpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hZGREaXNwb3NhYmxlUmVzb3VyY2UoZW52LCB2YWx1ZSwgYXN5bmMpIHtcclxuICAgIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdm9pZCAwKSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBleHBlY3RlZC5cIik7XHJcbiAgICAgICAgdmFyIGRpc3Bvc2UsIGlubmVyO1xyXG4gICAgICAgIGlmIChhc3luYykge1xyXG4gICAgICAgICAgICBpZiAoIVN5bWJvbC5hc3luY0Rpc3Bvc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNEaXNwb3NlIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgICAgICAgICAgZGlzcG9zZSA9IHZhbHVlW1N5bWJvbC5hc3luY0Rpc3Bvc2VdO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAoZGlzcG9zZSA9PT0gdm9pZCAwKSB7XHJcbiAgICAgICAgICAgIGlmICghU3ltYm9sLmRpc3Bvc2UpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuZGlzcG9zZSBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICAgICAgICAgIGRpc3Bvc2UgPSB2YWx1ZVtTeW1ib2wuZGlzcG9zZV07XHJcbiAgICAgICAgICAgIGlmIChhc3luYykgaW5uZXIgPSBkaXNwb3NlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZiAodHlwZW9mIGRpc3Bvc2UgIT09IFwiZnVuY3Rpb25cIikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIk9iamVjdCBub3QgZGlzcG9zYWJsZS5cIik7XHJcbiAgICAgICAgaWYgKGlubmVyKSBkaXNwb3NlID0gZnVuY3Rpb24oKSB7IHRyeSB7IGlubmVyLmNhbGwodGhpcyk7IH0gY2F0Y2ggKGUpIHsgcmV0dXJuIFByb21pc2UucmVqZWN0KGUpOyB9IH07XHJcbiAgICAgICAgZW52LnN0YWNrLnB1c2goeyB2YWx1ZTogdmFsdWUsIGRpc3Bvc2U6IGRpc3Bvc2UsIGFzeW5jOiBhc3luYyB9KTtcclxuICAgIH1cclxuICAgIGVsc2UgaWYgKGFzeW5jKSB7XHJcbiAgICAgICAgZW52LnN0YWNrLnB1c2goeyBhc3luYzogdHJ1ZSB9KTtcclxuICAgIH1cclxuICAgIHJldHVybiB2YWx1ZTtcclxuXHJcbn1cclxuXHJcbnZhciBfU3VwcHJlc3NlZEVycm9yID0gdHlwZW9mIFN1cHByZXNzZWRFcnJvciA9PT0gXCJmdW5jdGlvblwiID8gU3VwcHJlc3NlZEVycm9yIDogZnVuY3Rpb24gKGVycm9yLCBzdXBwcmVzc2VkLCBtZXNzYWdlKSB7XHJcbiAgICB2YXIgZSA9IG5ldyBFcnJvcihtZXNzYWdlKTtcclxuICAgIHJldHVybiBlLm5hbWUgPSBcIlN1cHByZXNzZWRFcnJvclwiLCBlLmVycm9yID0gZXJyb3IsIGUuc3VwcHJlc3NlZCA9IHN1cHByZXNzZWQsIGU7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19kaXNwb3NlUmVzb3VyY2VzKGVudikge1xyXG4gICAgZnVuY3Rpb24gZmFpbChlKSB7XHJcbiAgICAgICAgZW52LmVycm9yID0gZW52Lmhhc0Vycm9yID8gbmV3IF9TdXBwcmVzc2VkRXJyb3IoZSwgZW52LmVycm9yLCBcIkFuIGVycm9yIHdhcyBzdXBwcmVzc2VkIGR1cmluZyBkaXNwb3NhbC5cIikgOiBlO1xyXG4gICAgICAgIGVudi5oYXNFcnJvciA9IHRydWU7XHJcbiAgICB9XHJcbiAgICB2YXIgciwgcyA9IDA7XHJcbiAgICBmdW5jdGlvbiBuZXh0KCkge1xyXG4gICAgICAgIHdoaWxlIChyID0gZW52LnN0YWNrLnBvcCgpKSB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBpZiAoIXIuYXN5bmMgJiYgcyA9PT0gMSkgcmV0dXJuIHMgPSAwLCBlbnYuc3RhY2sucHVzaChyKSwgUHJvbWlzZS5yZXNvbHZlKCkudGhlbihuZXh0KTtcclxuICAgICAgICAgICAgICAgIGlmIChyLmRpc3Bvc2UpIHtcclxuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gci5kaXNwb3NlLmNhbGwoci52YWx1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHIuYXN5bmMpIHJldHVybiBzIHw9IDIsIFByb21pc2UucmVzb2x2ZShyZXN1bHQpLnRoZW4obmV4dCwgZnVuY3Rpb24oZSkgeyBmYWlsKGUpOyByZXR1cm4gbmV4dCgpOyB9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGVsc2UgcyB8PSAxO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBmYWlsKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmIChzID09PSAxKSByZXR1cm4gZW52Lmhhc0Vycm9yID8gUHJvbWlzZS5yZWplY3QoZW52LmVycm9yKSA6IFByb21pc2UucmVzb2x2ZSgpO1xyXG4gICAgICAgIGlmIChlbnYuaGFzRXJyb3IpIHRocm93IGVudi5lcnJvcjtcclxuICAgIH1cclxuICAgIHJldHVybiBuZXh0KCk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbihwYXRoLCBwcmVzZXJ2ZUpzeCkge1xyXG4gICAgaWYgKHR5cGVvZiBwYXRoID09PSBcInN0cmluZ1wiICYmIC9eXFwuXFwuP1xcLy8udGVzdChwYXRoKSkge1xyXG4gICAgICAgIHJldHVybiBwYXRoLnJlcGxhY2UoL1xcLih0c3gpJHwoKD86XFwuZCk/KSgoPzpcXC5bXi4vXSs/KT8pXFwuKFtjbV0/KXRzJC9pLCBmdW5jdGlvbiAobSwgdHN4LCBkLCBleHQsIGNtKSB7XHJcbiAgICAgICAgICAgIHJldHVybiB0c3ggPyBwcmVzZXJ2ZUpzeCA/IFwiLmpzeFwiIDogXCIuanNcIiA6IGQgJiYgKCFleHQgfHwgIWNtKSA/IG0gOiAoZCArIGV4dCArIFwiLlwiICsgY20udG9Mb3dlckNhc2UoKSArIFwianNcIik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gcGF0aDtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gICAgX19leHRlbmRzOiBfX2V4dGVuZHMsXHJcbiAgICBfX2Fzc2lnbjogX19hc3NpZ24sXHJcbiAgICBfX3Jlc3Q6IF9fcmVzdCxcclxuICAgIF9fZGVjb3JhdGU6IF9fZGVjb3JhdGUsXHJcbiAgICBfX3BhcmFtOiBfX3BhcmFtLFxyXG4gICAgX19lc0RlY29yYXRlOiBfX2VzRGVjb3JhdGUsXHJcbiAgICBfX3J1bkluaXRpYWxpemVyczogX19ydW5Jbml0aWFsaXplcnMsXHJcbiAgICBfX3Byb3BLZXk6IF9fcHJvcEtleSxcclxuICAgIF9fc2V0RnVuY3Rpb25OYW1lOiBfX3NldEZ1bmN0aW9uTmFtZSxcclxuICAgIF9fbWV0YWRhdGE6IF9fbWV0YWRhdGEsXHJcbiAgICBfX2F3YWl0ZXI6IF9fYXdhaXRlcixcclxuICAgIF9fZ2VuZXJhdG9yOiBfX2dlbmVyYXRvcixcclxuICAgIF9fY3JlYXRlQmluZGluZzogX19jcmVhdGVCaW5kaW5nLFxyXG4gICAgX19leHBvcnRTdGFyOiBfX2V4cG9ydFN0YXIsXHJcbiAgICBfX3ZhbHVlczogX192YWx1ZXMsXHJcbiAgICBfX3JlYWQ6IF9fcmVhZCxcclxuICAgIF9fc3ByZWFkOiBfX3NwcmVhZCxcclxuICAgIF9fc3ByZWFkQXJyYXlzOiBfX3NwcmVhZEFycmF5cyxcclxuICAgIF9fc3ByZWFkQXJyYXk6IF9fc3ByZWFkQXJyYXksXHJcbiAgICBfX2F3YWl0OiBfX2F3YWl0LFxyXG4gICAgX19hc3luY0dlbmVyYXRvcjogX19hc3luY0dlbmVyYXRvcixcclxuICAgIF9fYXN5bmNEZWxlZ2F0b3I6IF9fYXN5bmNEZWxlZ2F0b3IsXHJcbiAgICBfX2FzeW5jVmFsdWVzOiBfX2FzeW5jVmFsdWVzLFxyXG4gICAgX19tYWtlVGVtcGxhdGVPYmplY3Q6IF9fbWFrZVRlbXBsYXRlT2JqZWN0LFxyXG4gICAgX19pbXBvcnRTdGFyOiBfX2ltcG9ydFN0YXIsXHJcbiAgICBfX2ltcG9ydERlZmF1bHQ6IF9faW1wb3J0RGVmYXVsdCxcclxuICAgIF9fY2xhc3NQcml2YXRlRmllbGRHZXQ6IF9fY2xhc3NQcml2YXRlRmllbGRHZXQsXHJcbiAgICBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0OiBfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0LFxyXG4gICAgX19jbGFzc1ByaXZhdGVGaWVsZEluOiBfX2NsYXNzUHJpdmF0ZUZpZWxkSW4sXHJcbiAgICBfX2FkZERpc3Bvc2FibGVSZXNvdXJjZTogX19hZGREaXNwb3NhYmxlUmVzb3VyY2UsXHJcbiAgICBfX2Rpc3Bvc2VSZXNvdXJjZXM6IF9fZGlzcG9zZVJlc291cmNlcyxcclxuICAgIF9fcmV3cml0ZVJlbGF0aXZlSW1wb3J0RXh0ZW5zaW9uOiBfX3Jld3JpdGVSZWxhdGl2ZUltcG9ydEV4dGVuc2lvbixcclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IFRBR01BU1RFUl9WSUVXX1RZUEUgPSAndGFnbWFzdGVyLXZpZXcnO1xuXG5leHBvcnQgY29uc3QgVEFHX1JFR0VYID0gLyMoW2EtekEtWjAtOV9cXC1cXC9dKykvZztcbmV4cG9ydCBjb25zdCBUQUdfV0lUSF9CT1VOREFSWSA9IC8oPzpefFteYS16QS1aMC05X1xcLVxcL10pIyhbYS16QS1aMC05X1xcLVxcL10rKSg/OlteYS16QS1aMC05X1xcLVxcL118JCkvZztcbiIsImltcG9ydCB7IFRGaWxlLCBWYXVsdCwgTWV0YWRhdGFDYWNoZSB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IHBhcnNlQWxsRG9jdW1lbnRzIH0gZnJvbSAneWFtbCc7XG5pbXBvcnQgdHlwZSB7IFRhZ09jY3VycmVuY2UsIFRhZ0luZm8sIFRhZ01hc3RlclNldHRpbmdzIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgVEFHX1dJVEhfQk9VTkRBUlkgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuXG5leHBvcnQgY2xhc3MgVGFnSW5kZXhlciB7XG4gICAgcHJpdmF0ZSB2YXVsdDogVmF1bHQ7XG4gICAgcHJpdmF0ZSBtZXRhZGF0YUNhY2hlOiBNZXRhZGF0YUNhY2hlO1xuICAgIHByaXZhdGUgc2V0dGluZ3M6IFRhZ01hc3RlclNldHRpbmdzO1xuICAgIHByaXZhdGUgdGFnQ2F0YWxvZzogTWFwPHN0cmluZywgVGFnSW5mbz47XG4gICAgcHJpdmF0ZSBpc0luZGV4aW5nOiBib29sZWFuID0gZmFsc2U7XG5cbiAgICBjb25zdHJ1Y3Rvcih2YXVsdDogVmF1bHQsIG1ldGFkYXRhQ2FjaGU6IE1ldGFkYXRhQ2FjaGUsIHNldHRpbmdzOiBUYWdNYXN0ZXJTZXR0aW5ncykge1xuICAgICAgICB0aGlzLnZhdWx0ID0gdmF1bHQ7XG4gICAgICAgIHRoaXMubWV0YWRhdGFDYWNoZSA9IG1ldGFkYXRhQ2FjaGU7XG4gICAgICAgIHRoaXMuc2V0dGluZ3MgPSBzZXR0aW5ncztcbiAgICAgICAgdGhpcy50YWdDYXRhbG9nID0gbmV3IE1hcCgpO1xuICAgIH1cblxuICAgIGFzeW5jIGluZGV4VmF1bHQob25Qcm9ncmVzcz86IChjdXJyZW50OiBudW1iZXIsIHRvdGFsOiBudW1iZXIpID0+IHZvaWQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAgICAgaWYgKHRoaXMuaXNJbmRleGluZykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKCdUYWdNYXN0ZXI6IEluZGV4aW5nIGFscmVhZHkgaW4gcHJvZ3Jlc3MnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMuaXNJbmRleGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMudGFnQ2F0YWxvZy5jbGVhcigpO1xuXG4gICAgICAgIGNvbnN0IGZpbGVzID0gdGhpcy52YXVsdC5nZXRNYXJrZG93bkZpbGVzKCk7XG4gICAgICAgIGNvbnN0IHRvdGFsID0gZmlsZXMubGVuZ3RoO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdG90YWw7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgZmlsZSA9IGZpbGVzW2ldO1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5pbmRleEZpbGUoZmlsZSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmIChvblByb2dyZXNzKSB7XG4gICAgICAgICAgICAgICAgb25Qcm9ncmVzcyhpICsgMSwgdG90YWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5pc0luZGV4aW5nID0gZmFsc2U7XG4gICAgfVxuXG4gICAgYXN5bmMgaW5kZXhGaWxlKGZpbGU6IFRGaWxlKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB0aGlzLnZhdWx0LmNhY2hlZFJlYWQoZmlsZSk7XG4gICAgICAgIGNvbnN0IGxpbmVzID0gY29udGVudC5zcGxpdCgnXFxuJyk7XG5cbiAgICAgICAgLy8gSW5kZXggZnJvbnRtYXR0ZXIgdGFnc1xuICAgICAgICBjb25zdCBmcm9udG1hdHRlciA9IHRoaXMubWV0YWRhdGFDYWNoZS5nZXRGaWxlQ2FjaGUoZmlsZSk/LmZyb250bWF0dGVyO1xuICAgICAgICBpZiAoZnJvbnRtYXR0ZXI/LnRhZ3MpIHtcbiAgICAgICAgICAgIHRoaXMuaW5kZXhGcm9udG1hdHRlclRhZ3MoZmlsZSwgZnJvbnRtYXR0ZXIudGFncywgY29udGVudCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbmRleCBpbmxpbmUgdGFnc1xuICAgICAgICBsaW5lcy5mb3JFYWNoKChsaW5lLCBsaW5lTnVtYmVyKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmluZGV4SW5saW5lVGFncyhmaWxlLCBsaW5lLCBsaW5lTnVtYmVyKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBpbmRleEZyb250bWF0dGVyVGFncyhmaWxlOiBURmlsZSwgdGFnczogc3RyaW5nIHwgc3RyaW5nW10sIGNvbnRlbnQ6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBjb25zdCB0YWdBcnJheSA9IEFycmF5LmlzQXJyYXkodGFncykgPyB0YWdzIDogW3RhZ3NdO1xuICAgICAgICBjb25zdCBsaW5lcyA9IGNvbnRlbnQuc3BsaXQoJ1xcbicpO1xuXG4gICAgICAgIHRhZ0FycmF5LmZvckVhY2godGFnID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNsZWFuVGFnID0gdGFnLnN0YXJ0c1dpdGgoJyMnKSA/IHRhZyA6IGAjJHt0YWd9YDtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gRmluZCB0aGUgbGluZSB3aGVyZSB0aGlzIHRhZyBhcHBlYXJzIGluIGZyb250bWF0dGVyXG4gICAgICAgICAgICBsZXQgbGluZU51bWJlciA9IDA7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxpbmVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKGxpbmVzW2ldLmluY2x1ZGVzKHRhZykpIHtcbiAgICAgICAgICAgICAgICAgICAgbGluZU51bWJlciA9IGk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY29uc3Qgb2NjdXJyZW5jZTogVGFnT2NjdXJyZW5jZSA9IHtcbiAgICAgICAgICAgICAgICBmaWxlOiBmaWxlLnBhdGgsXG4gICAgICAgICAgICAgICAgbGluZTogbGluZU51bWJlcixcbiAgICAgICAgICAgICAgICBjb250ZXh0OiBsaW5lc1tsaW5lTnVtYmVyXSB8fCAnJyxcbiAgICAgICAgICAgICAgICBpc0Zyb250bWF0dGVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIHN0YXJ0SW5kZXg6IDAsXG4gICAgICAgICAgICAgICAgZW5kSW5kZXg6IHRhZy5sZW5ndGhcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHRoaXMuYWRkT2NjdXJyZW5jZShjbGVhblRhZywgb2NjdXJyZW5jZSk7XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgaW5kZXhJbmxpbmVUYWdzKGZpbGU6IFRGaWxlLCBsaW5lOiBzdHJpbmcsIGxpbmVOdW1iZXI6IG51bWJlcik6IHZvaWQge1xuICAgICAgICBjb25zdCBtYXRjaGVzID0gWy4uLmxpbmUubWF0Y2hBbGwoVEFHX1dJVEhfQk9VTkRBUlkpXTtcblxuICAgICAgICBtYXRjaGVzLmZvckVhY2gobWF0Y2ggPT4ge1xuICAgICAgICAgICAgaWYgKG1hdGNoWzFdKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdGFnID0gYCMke21hdGNoWzFdfWA7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2NjdXJyZW5jZTogVGFnT2NjdXJyZW5jZSA9IHtcbiAgICAgICAgICAgICAgICAgICAgZmlsZTogZmlsZS5wYXRoLFxuICAgICAgICAgICAgICAgICAgICBsaW5lOiBsaW5lTnVtYmVyLFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0OiBsaW5lLFxuICAgICAgICAgICAgICAgICAgICBpc0Zyb250bWF0dGVyOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgc3RhcnRJbmRleDogbWF0Y2guaW5kZXggfHwgMCxcbiAgICAgICAgICAgICAgICAgICAgZW5kSW5kZXg6IChtYXRjaC5pbmRleCB8fCAwKSArIHRhZy5sZW5ndGhcbiAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgdGhpcy5hZGRPY2N1cnJlbmNlKHRhZywgb2NjdXJyZW5jZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cblxuICAgIHByaXZhdGUgYWRkT2NjdXJyZW5jZSh0YWc6IHN0cmluZywgb2NjdXJyZW5jZTogVGFnT2NjdXJyZW5jZSk6IHZvaWQge1xuICAgICAgICBjb25zdCBub3JtYWxpemVkVGFnID0gdGhpcy5ub3JtYWxpemVUYWcodGFnKTtcbiAgICAgICAgXG4gICAgICAgIGxldCB0YWdJbmZvID0gdGhpcy50YWdDYXRhbG9nLmdldCh0YWcpO1xuICAgICAgICBpZiAoIXRhZ0luZm8pIHtcbiAgICAgICAgICAgIHRhZ0luZm8gPSB7XG4gICAgICAgICAgICAgICAgdGFnLFxuICAgICAgICAgICAgICAgIG5vcm1hbGl6ZWRUYWcsXG4gICAgICAgICAgICAgICAgY291bnQ6IDAsXG4gICAgICAgICAgICAgICAgb2NjdXJyZW5jZXM6IFtdXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy50YWdDYXRhbG9nLnNldCh0YWcsIHRhZ0luZm8pO1xuICAgICAgICB9XG5cbiAgICAgICAgdGFnSW5mby5vY2N1cnJlbmNlcy5wdXNoKG9jY3VycmVuY2UpO1xuICAgICAgICB0YWdJbmZvLmNvdW50ID0gdGFnSW5mby5vY2N1cnJlbmNlcy5sZW5ndGg7XG4gICAgfVxuXG4gICAgcHJpdmF0ZSBub3JtYWxpemVUYWcodGFnOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgICAgICBsZXQgbm9ybWFsaXplZCA9IHRhZy50b0xvd2VyQ2FzZSgpO1xuXG4gICAgICAgIGlmICh0aGlzLnNldHRpbmdzLm5vcm1hbGl6YXRpb25SdWxlcy5yZW1vdmVEaWFjcml0aWNzKSB7XG4gICAgICAgICAgICBub3JtYWxpemVkID0gbm9ybWFsaXplZC5ub3JtYWxpemUoJ05GRCcpLnJlcGxhY2UoL1tcXHUwMzAwLVxcdTAzNmZdL2csICcnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLnNldHRpbmdzLm5vcm1hbGl6YXRpb25SdWxlcy51bmRlcnNjb3Jlc1RvRGFzaGVzKSB7XG4gICAgICAgICAgICBub3JtYWxpemVkID0gbm9ybWFsaXplZC5yZXBsYWNlKC9fL2csICctJyk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5zZXR0aW5ncy5ub3JtYWxpemF0aW9uUnVsZXMuc3RyaXBQdW5jdHVhdGlvbikge1xuICAgICAgICAgICAgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZWQucmVwbGFjZSgvW15cXHdcXHNcXC1cXC9dL2csICcnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBub3JtYWxpemVkO1xuICAgIH1cblxuICAgIGdldENhdGFsb2coKTogTWFwPHN0cmluZywgVGFnSW5mbz4ge1xuICAgICAgICByZXR1cm4gdGhpcy50YWdDYXRhbG9nO1xuICAgIH1cblxuICAgIGdldFRhZ0luZm8odGFnOiBzdHJpbmcpOiBUYWdJbmZvIHwgdW5kZWZpbmVkIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFnQ2F0YWxvZy5nZXQodGFnKTtcbiAgICB9XG5cbiAgICBnZXRBbGxUYWdzKCk6IHN0cmluZ1tdIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20odGhpcy50YWdDYXRhbG9nLmtleXMoKSk7XG4gICAgfVxuXG4gICAgZ2V0VGFnQ291bnQoKTogbnVtYmVyIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudGFnQ2F0YWxvZy5zaXplO1xuICAgIH1cblxuICAgIHJlbW92ZUZpbGVGcm9tSW5kZXgoZmlsZVBhdGg6IHN0cmluZyk6IHZvaWQge1xuICAgICAgICBmb3IgKGNvbnN0IFt0YWcsIGluZm9dIG9mIHRoaXMudGFnQ2F0YWxvZy5lbnRyaWVzKCkpIHtcbiAgICAgICAgICAgIGluZm8ub2NjdXJyZW5jZXMgPSBpbmZvLm9jY3VycmVuY2VzLmZpbHRlcihvY2MgPT4gb2NjLmZpbGUgIT09IGZpbGVQYXRoKTtcbiAgICAgICAgICAgIGluZm8uY291bnQgPSBpbmZvLm9jY3VycmVuY2VzLmxlbmd0aDtcblxuICAgICAgICAgICAgaWYgKGluZm8uY291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnRhZ0NhdGFsb2cuZGVsZXRlKHRhZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCJpbXBvcnQgeyBBcHAsIFBsdWdpblNldHRpbmdUYWIsIFNldHRpbmcgfSBmcm9tICdvYnNpZGlhbic7XG5pbXBvcnQgdHlwZSBUYWdNYXN0ZXJQbHVnaW4gZnJvbSAnLi4vLi4vbWFpbic7XG5cbmV4cG9ydCBjbGFzcyBUYWdNYXN0ZXJTZXR0aW5nc1RhYiBleHRlbmRzIFBsdWdpblNldHRpbmdUYWIge1xuICAgIHBsdWdpbjogVGFnTWFzdGVyUGx1Z2luO1xuXG4gICAgY29uc3RydWN0b3IoYXBwOiBBcHAsIHBsdWdpbjogVGFnTWFzdGVyUGx1Z2luKSB7XG4gICAgICAgIHN1cGVyKGFwcCwgcGx1Z2luKTtcbiAgICAgICAgdGhpcy5wbHVnaW4gPSBwbHVnaW47XG4gICAgfVxuXG4gICAgZGlzcGxheSgpOiB2b2lkIHtcbiAgICAgICAgY29uc3QgeyBjb250YWluZXJFbCB9ID0gdGhpcztcbiAgICAgICAgY29udGFpbmVyRWwuZW1wdHkoKTtcblxuICAgICAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDInLCB7IHRleHQ6ICdUYWdNYXN0ZXIgU2V0dGluZ3MnIH0pO1xuXG4gICAgICAgIC8vIE5vcm1hbGl6YXRpb24gUnVsZXNcbiAgICAgICAgY29udGFpbmVyRWwuY3JlYXRlRWwoJ2gzJywgeyB0ZXh0OiAnTm9ybWFsaXphdGlvbiBSdWxlcycgfSk7XG5cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnQ2FzZSBmb2xkaW5nJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdDb252ZXJ0IHRhZ3MgdG8gbG93ZXJjYXNlIGZvciBjb21wYXJpc29uJylcbiAgICAgICAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5ub3JtYWxpemF0aW9uUnVsZXMuY2FzZUZvbGRpbmcpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5ub3JtYWxpemF0aW9uUnVsZXMuY2FzZUZvbGRpbmcgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgICAgICAgLnNldE5hbWUoJ1JlbW92ZSBkaWFjcml0aWNzJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdSZW1vdmUgYWNjZW50cyBhbmQgZGlhY3JpdGljYWwgbWFya3MgKMOpIOKGkiBlKScpXG4gICAgICAgICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Mubm9ybWFsaXphdGlvblJ1bGVzLnJlbW92ZURpYWNyaXRpY3MpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5ub3JtYWxpemF0aW9uUnVsZXMucmVtb3ZlRGlhY3JpdGljcyA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnVW5kZXJzY29yZXMgdG8gZGFzaGVzJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdUcmVhdCB1bmRlcnNjb3JlcyBhcyBkYXNoZXMgKCN0YWdfbmFtZSDihpIgI3RhZy1uYW1lKScpXG4gICAgICAgICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Mubm9ybWFsaXphdGlvblJ1bGVzLnVuZGVyc2NvcmVzVG9EYXNoZXMpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5ub3JtYWxpemF0aW9uUnVsZXMudW5kZXJzY29yZXNUb0Rhc2hlcyA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnU3RyaXAgcHVuY3R1YXRpb24nKVxuICAgICAgICAgICAgLnNldERlc2MoJ1JlbW92ZSBwdW5jdHVhdGlvbiBmcm9tIHRhZ3MnKVxuICAgICAgICAgICAgLmFkZFRvZ2dsZSh0b2dnbGUgPT4gdG9nZ2xlXG4gICAgICAgICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLm5vcm1hbGl6YXRpb25SdWxlcy5zdHJpcFB1bmN0dWF0aW9uKVxuICAgICAgICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3Mubm9ybWFsaXphdGlvblJ1bGVzLnN0cmlwUHVuY3R1YXRpb24gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uc2F2ZVNldHRpbmdzKCk7XG4gICAgICAgICAgICAgICAgfSkpO1xuXG4gICAgICAgIC8vIFNpbWlsYXJpdHkgVGhyZXNob2xkc1xuICAgICAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDMnLCB7IHRleHQ6ICdTaW1pbGFyaXR5IFRocmVzaG9sZHMgKDAtMSknIH0pO1xuXG4gICAgICAgIG5ldyBTZXR0aW5nKGNvbnRhaW5lckVsKVxuICAgICAgICAgICAgLnNldE5hbWUoJ0xldmVuc2h0ZWluIHRocmVzaG9sZCcpXG4gICAgICAgICAgICAuc2V0RGVzYygnTWluaW11bSBzaW1pbGFyaXR5IGZvciBMZXZlbnNodGVpbiBkaXN0YW5jZSAoaGlnaGVyID0gbW9yZSBzdHJpY3QpJylcbiAgICAgICAgICAgIC5hZGRTbGlkZXIoc2xpZGVyID0+IHNsaWRlclxuICAgICAgICAgICAgICAgIC5zZXRMaW1pdHMoMCwgMSwgMC4wNSlcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2ltaWxhcml0eVRocmVzaG9sZHMubGV2ZW5zaHRlaW4pXG4gICAgICAgICAgICAgICAgLnNldER5bmFtaWNUb29sdGlwKClcbiAgICAgICAgICAgICAgICAub25DaGFuZ2UoYXN5bmMgKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucGx1Z2luLnNldHRpbmdzLnNpbWlsYXJpdHlUaHJlc2hvbGRzLmxldmVuc2h0ZWluID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdKYXJvLVdpbmtsZXIgdGhyZXNob2xkJylcbiAgICAgICAgICAgIC5zZXREZXNjKCdNaW5pbXVtIHNpbWlsYXJpdHkgZm9yIEphcm8tV2lua2xlciBkaXN0YW5jZScpXG4gICAgICAgICAgICAuYWRkU2xpZGVyKHNsaWRlciA9PiBzbGlkZXJcbiAgICAgICAgICAgICAgICAuc2V0TGltaXRzKDAsIDEsIDAuMDUpXG4gICAgICAgICAgICAgICAgLnNldFZhbHVlKHRoaXMucGx1Z2luLnNldHRpbmdzLnNpbWlsYXJpdHlUaHJlc2hvbGRzLmphcm9XaW5rbGVyKVxuICAgICAgICAgICAgICAgIC5zZXREeW5hbWljVG9vbHRpcCgpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zaW1pbGFyaXR5VGhyZXNob2xkcy5qYXJvV2lua2xlciA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgLy8gUHJldmlldyBTZXR0aW5nc1xuICAgICAgICBjb250YWluZXJFbC5jcmVhdGVFbCgnaDMnLCB7IHRleHQ6ICdQcmV2aWV3IFNldHRpbmdzJyB9KTtcblxuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdNYXggcHJldmlldyBleGFtcGxlcycpXG4gICAgICAgICAgICAuc2V0RGVzYygnTnVtYmVyIG9mIGV4YW1wbGVzIHRvIHNob3cgaW4gcHJldmlldycpXG4gICAgICAgICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUoU3RyaW5nKHRoaXMucGx1Z2luLnNldHRpbmdzLnByZXZpZXdTZXR0aW5ncy5tYXhFeGFtcGxlcykpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBudW0gPSBwYXJzZUludCh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmICghaXNOYU4obnVtKSAmJiBudW0gPiAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5wcmV2aWV3U2V0dGluZ3MubWF4RXhhbXBsZXMgPSBudW07XG4gICAgICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pKTtcblxuICAgICAgICAvLyBTYWZldHlcbiAgICAgICAgY29udGFpbmVyRWwuY3JlYXRlRWwoJ2gzJywgeyB0ZXh0OiAnU2FmZXR5JyB9KTtcblxuICAgICAgICBuZXcgU2V0dGluZyhjb250YWluZXJFbClcbiAgICAgICAgICAgIC5zZXROYW1lKCdTYWZlIG1vZGUnKVxuICAgICAgICAgICAgLnNldERlc2MoJ1JlcXVpcmUgZHJ5LXJ1biBiZWZvcmUgYXBwbHlpbmcgY2hhbmdlcycpXG4gICAgICAgICAgICAuYWRkVG9nZ2xlKHRvZ2dsZSA9PiB0b2dnbGVcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUodGhpcy5wbHVnaW4uc2V0dGluZ3Muc2FmZU1vZGUpXG4gICAgICAgICAgICAgICAgLm9uQ2hhbmdlKGFzeW5jICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnBsdWdpbi5zZXR0aW5ncy5zYWZlTW9kZSA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnRW5hYmxlIHVuZG8nKVxuICAgICAgICAgICAgLnNldERlc2MoJ0tlZXAgYmFja3VwIHNuYXBzaG90cyBmb3IgdW5kbyBvcGVyYXRpb25zJylcbiAgICAgICAgICAgIC5hZGRUb2dnbGUodG9nZ2xlID0+IHRvZ2dsZVxuICAgICAgICAgICAgICAgIC5zZXRWYWx1ZSh0aGlzLnBsdWdpbi5zZXR0aW5ncy5lbmFibGVVbmRvKVxuICAgICAgICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MuZW5hYmxlVW5kbyA9IHZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLnBsdWdpbi5zYXZlU2V0dGluZ3MoKTtcbiAgICAgICAgICAgICAgICB9KSk7XG5cbiAgICAgICAgbmV3IFNldHRpbmcoY29udGFpbmVyRWwpXG4gICAgICAgICAgICAuc2V0TmFtZSgnTWF4IGJhY2t1cHMnKVxuICAgICAgICAgICAgLnNldERlc2MoJ01heGltdW0gbnVtYmVyIG9mIGJhY2t1cCBzbmFwc2hvdHMgdG8ga2VlcCcpXG4gICAgICAgICAgICAuYWRkVGV4dCh0ZXh0ID0+IHRleHRcbiAgICAgICAgICAgICAgICAuc2V0VmFsdWUoU3RyaW5nKHRoaXMucGx1Z2luLnNldHRpbmdzLm1heEJhY2t1cHMpKVxuICAgICAgICAgICAgICAgIC5vbkNoYW5nZShhc3luYyAodmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbnVtID0gcGFyc2VJbnQodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWlzTmFOKG51bSkgJiYgbnVtID4gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wbHVnaW4uc2V0dGluZ3MubWF4QmFja3VwcyA9IG51bTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHRoaXMucGx1Z2luLnNhdmVTZXR0aW5ncygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IEl0ZW1WaWV3LCBXb3Jrc3BhY2VMZWFmIH0gZnJvbSAnb2JzaWRpYW4nO1xuaW1wb3J0IHsgVEFHTUFTVEVSX1ZJRVdfVFlQRSB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5pbXBvcnQgdHlwZSBUYWdNYXN0ZXJQbHVnaW4gZnJvbSAnLi4vLi4vbWFpbic7XG5cbmV4cG9ydCBjbGFzcyBUYWdNYXN0ZXJWaWV3IGV4dGVuZHMgSXRlbVZpZXcge1xuICAgIHBsdWdpbjogVGFnTWFzdGVyUGx1Z2luO1xuXG4gICAgY29uc3RydWN0b3IobGVhZjogV29ya3NwYWNlTGVhZiwgcGx1Z2luOiBUYWdNYXN0ZXJQbHVnaW4pIHtcbiAgICAgICAgc3VwZXIobGVhZik7XG4gICAgICAgIHRoaXMucGx1Z2luID0gcGx1Z2luO1xuICAgIH1cblxuICAgIGdldFZpZXdUeXBlKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiBUQUdNQVNURVJfVklFV19UWVBFO1xuICAgIH1cblxuICAgIGdldERpc3BsYXlUZXh0KCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiAnVGFnTWFzdGVyJztcbiAgICB9XG5cbiAgICBnZXRJY29uKCk6IHN0cmluZyB7XG4gICAgICAgIHJldHVybiAndGFncyc7XG4gICAgfVxuXG4gICAgYXN5bmMgb25PcGVuKCkge1xuICAgICAgICBjb25zdCBjb250YWluZXIgPSB0aGlzLmNvbnRhaW5lckVsLmNoaWxkcmVuWzFdO1xuICAgICAgICBjb250YWluZXIuZW1wdHkoKTtcbiAgICAgICAgY29udGFpbmVyLmFkZENsYXNzKCd0YWdtYXN0ZXItdmlldycpO1xuXG4gICAgICAgIC8vIEhlYWRlclxuICAgICAgICBjb25zdCBoZWFkZXIgPSBjb250YWluZXIuY3JlYXRlRWwoJ2RpdicsIHsgY2xzOiAndGFnbWFzdGVyLWhlYWRlcicgfSk7XG4gICAgICAgIGhlYWRlci5jcmVhdGVFbCgnaDMnLCB7IHRleHQ6ICdUYWcgQ2F0YWxvZycgfSk7XG5cbiAgICAgICAgY29uc3Qgc2NhbkJ1dHRvbiA9IGhlYWRlci5jcmVhdGVFbCgnYnV0dG9uJywgeyB0ZXh0OiAnU2NhbiBWYXVsdCcsIGNsczogJ21vZC1jdGEnIH0pO1xuICAgICAgICBzY2FuQnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgc2NhbkJ1dHRvbi5kaXNhYmxlZCA9IHRydWU7XG4gICAgICAgICAgICBzY2FuQnV0dG9uLnRleHRDb250ZW50ID0gJ1NjYW5uaW5nLi4uJztcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgYXdhaXQgdGhpcy5wbHVnaW4uaW5kZXhlci5pbmRleFZhdWx0KChjdXJyZW50LCB0b3RhbCkgPT4ge1xuICAgICAgICAgICAgICAgIHNjYW5CdXR0b24udGV4dENvbnRlbnQgPSBgU2Nhbm5pbmcgJHtjdXJyZW50fS8ke3RvdGFsfWA7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgc2NhbkJ1dHRvbi50ZXh0Q29udGVudCA9ICdTY2FuIFZhdWx0JztcbiAgICAgICAgICAgIHNjYW5CdXR0b24uZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyVGFnTGlzdCgpO1xuICAgICAgICB9KTtcblxuICAgICAgICAvLyBTdGF0c1xuICAgICAgICBjb25zdCBzdGF0cyA9IGNvbnRhaW5lci5jcmVhdGVFbCgnZGl2JywgeyBjbHM6ICd0YWdtYXN0ZXItc3RhdHMnIH0pO1xuICAgICAgICB0aGlzLnJlbmRlclN0YXRzKHN0YXRzKTtcblxuICAgICAgICAvLyBUYWcgbGlzdFxuICAgICAgICBjb25zdCBsaXN0Q29udGFpbmVyID0gY29udGFpbmVyLmNyZWF0ZUVsKCdkaXYnLCB7IGNsczogJ3RhZ21hc3Rlci1saXN0JyB9KTtcbiAgICAgICAgdGhpcy5yZW5kZXJUYWdMaXN0KGxpc3RDb250YWluZXIpO1xuICAgIH1cblxuICAgIHByaXZhdGUgcmVuZGVyU3RhdHMoY29udGFpbmVyOiBIVE1MRWxlbWVudCkge1xuICAgICAgICBjb250YWluZXIuZW1wdHkoKTtcbiAgICAgICAgY29uc3QgdGFnQ291bnQgPSB0aGlzLnBsdWdpbi5pbmRleGVyLmdldFRhZ0NvdW50KCk7XG4gICAgICAgIGNvbnRhaW5lci5jcmVhdGVFbCgncCcsIHsgdGV4dDogYFRvdGFsIHRhZ3M6ICR7dGFnQ291bnR9YCB9KTtcbiAgICB9XG5cbiAgICBwcml2YXRlIHJlbmRlclRhZ0xpc3QoY29udGFpbmVyPzogSFRNTEVsZW1lbnQpIHtcbiAgICAgICAgY29uc3QgbGlzdEVsID0gY29udGFpbmVyIHx8IHRoaXMuY29udGFpbmVyRWwucXVlcnlTZWxlY3RvcignLnRhZ21hc3Rlci1saXN0Jyk7XG4gICAgICAgIGlmICghbGlzdEVsKSByZXR1cm47XG5cbiAgICAgICAgbGlzdEVsLmVtcHR5KCk7XG5cbiAgICAgICAgY29uc3QgY2F0YWxvZyA9IHRoaXMucGx1Z2luLmluZGV4ZXIuZ2V0Q2F0YWxvZygpO1xuICAgICAgICBjb25zdCBzb3J0ZWRUYWdzID0gQXJyYXkuZnJvbShjYXRhbG9nLmVudHJpZXMoKSlcbiAgICAgICAgICAgIC5zb3J0KChhLCBiKSA9PiBiWzFdLmNvdW50IC0gYVsxXS5jb3VudCk7XG5cbiAgICAgICAgc29ydGVkVGFncy5mb3JFYWNoKChbdGFnLCBpbmZvXSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgdGFnSXRlbSA9IGxpc3RFbC5jcmVhdGVFbCgnZGl2JywgeyBjbHM6ICd0YWdtYXN0ZXItdGFnLWl0ZW0nIH0pO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBjb25zdCB0YWdOYW1lID0gdGFnSXRlbS5jcmVhdGVFbCgnc3BhbicsIHsgXG4gICAgICAgICAgICAgICAgY2xzOiAndGFnbWFzdGVyLXRhZy1uYW1lJyxcbiAgICAgICAgICAgICAgICB0ZXh0OiB0YWcgXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc3QgdGFnQ291bnQgPSB0YWdJdGVtLmNyZWF0ZUVsKCdzcGFuJywgeyBcbiAgICAgICAgICAgICAgICBjbHM6ICd0YWdtYXN0ZXItdGFnLWNvdW50JyxcbiAgICAgICAgICAgICAgICB0ZXh0OiBgJHtpbmZvLmNvdW50fWAgXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdGFnSXRlbS5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dUYWdEZXRhaWxzKHRhZywgaW5mbyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gVXBkYXRlIHN0YXRzXG4gICAgICAgIGNvbnN0IHN0YXRzRWwgPSB0aGlzLmNvbnRhaW5lckVsLnF1ZXJ5U2VsZWN0b3IoJy50YWdtYXN0ZXItc3RhdHMnKTtcbiAgICAgICAgaWYgKHN0YXRzRWwpIHtcbiAgICAgICAgICAgIHRoaXMucmVuZGVyU3RhdHMoc3RhdHNFbCBhcyBIVE1MRWxlbWVudCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBwcml2YXRlIHNob3dUYWdEZXRhaWxzKHRhZzogc3RyaW5nLCBpbmZvOiBhbnkpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1RhZyBkZXRhaWxzOicsIHRhZywgaW5mbyk7XG4gICAgICAgIC8vIFRPRE86IEltcGxlbWVudCBtb2RhbCB3aXRoIHRhZyBkZXRhaWxzIGFuZCBhY3Rpb25zXG4gICAgfVxuXG4gICAgYXN5bmMgb25DbG9zZSgpIHtcbiAgICAgICAgLy8gQ2xlYW51cFxuICAgIH1cbn1cbiIsImV4cG9ydCBpbnRlcmZhY2UgVGFnT2NjdXJyZW5jZSB7XG4gICAgZmlsZTogc3RyaW5nO1xuICAgIGxpbmU6IG51bWJlcjtcbiAgICBjb250ZXh0OiBzdHJpbmc7XG4gICAgaXNGcm9udG1hdHRlcjogYm9vbGVhbjtcbiAgICBzdGFydEluZGV4OiBudW1iZXI7XG4gICAgZW5kSW5kZXg6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUYWdJbmZvIHtcbiAgICB0YWc6IHN0cmluZztcbiAgICBub3JtYWxpemVkVGFnOiBzdHJpbmc7XG4gICAgY291bnQ6IG51bWJlcjtcbiAgICBvY2N1cnJlbmNlczogVGFnT2NjdXJyZW5jZVtdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRhZ1N1Z2dlc3Rpb24ge1xuICAgIHNvdXJjZVRhZzogc3RyaW5nO1xuICAgIHRhcmdldFRhZzogc3RyaW5nO1xuICAgIHNpbWlsYXJpdHk6IG51bWJlcjtcbiAgICBvY2N1cnJlbmNlczogbnVtYmVyO1xuICAgIHJlYXNvbjogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRhZ01lcmdlT3BlcmF0aW9uIHtcbiAgICBpZDogc3RyaW5nO1xuICAgIHRpbWVzdGFtcDogbnVtYmVyO1xuICAgIHNvdXJjZVRhZ3M6IHN0cmluZ1tdO1xuICAgIHRhcmdldFRhZzogc3RyaW5nO1xuICAgIGFmZmVjdGVkRmlsZXM6IHN0cmluZ1tdO1xuICAgIHByZXZpZXc6IFRhZ09wZXJhdGlvblByZXZpZXdbXTtcbiAgICBzdGF0dXM6ICdwZW5kaW5nJyB8ICdhcHBsaWVkJyB8ICdyZXZlcnRlZCc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGFnT3BlcmF0aW9uUHJldmlldyB7XG4gICAgZmlsZTogc3RyaW5nO1xuICAgIGJlZm9yZTogc3RyaW5nO1xuICAgIGFmdGVyOiBzdHJpbmc7XG4gICAgbGluZTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJhY2t1cFNuYXBzaG90IHtcbiAgICBpZDogc3RyaW5nO1xuICAgIHRpbWVzdGFtcDogbnVtYmVyO1xuICAgIG9wZXJhdGlvbklkOiBzdHJpbmc7XG4gICAgZmlsZXM6IE1hcDxzdHJpbmcsIHN0cmluZz47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGFnTWFzdGVyU2V0dGluZ3Mge1xuICAgIG5vcm1hbGl6YXRpb25SdWxlczoge1xuICAgICAgICBjYXNlRm9sZGluZzogYm9vbGVhbjtcbiAgICAgICAgcmVtb3ZlRGlhY3JpdGljczogYm9vbGVhbjtcbiAgICAgICAgdW5kZXJzY29yZXNUb0Rhc2hlczogYm9vbGVhbjtcbiAgICAgICAgc3RyaXBQdW5jdHVhdGlvbjogYm9vbGVhbjtcbiAgICB9O1xuICAgIHNpbWlsYXJpdHlUaHJlc2hvbGRzOiB7XG4gICAgICAgIGxldmVuc2h0ZWluOiBudW1iZXI7XG4gICAgICAgIGphcm9XaW5rbGVyOiBudW1iZXI7XG4gICAgICAgIHRva2VuT3ZlcmxhcDogbnVtYmVyO1xuICAgIH07XG4gICAgcHJldmlld1NldHRpbmdzOiB7XG4gICAgICAgIG1heEV4YW1wbGVzOiBudW1iZXI7XG4gICAgICAgIGNvbnRleHRMaW5lczogbnVtYmVyO1xuICAgIH07XG4gICAgc2FmZU1vZGU6IGJvb2xlYW47XG4gICAgZW5hYmxlVW5kbzogYm9vbGVhbjtcbiAgICBtYXhCYWNrdXBzOiBudW1iZXI7XG4gICAgZW5hYmxlRW1iZWRkaW5nczogYm9vbGVhbjtcbiAgICBlbWJlZGRpbmdzQXBpS2V5Pzogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogVGFnTWFzdGVyU2V0dGluZ3MgPSB7XG4gICAgbm9ybWFsaXphdGlvblJ1bGVzOiB7XG4gICAgICAgIGNhc2VGb2xkaW5nOiB0cnVlLFxuICAgICAgICByZW1vdmVEaWFjcml0aWNzOiB0cnVlLFxuICAgICAgICB1bmRlcnNjb3Jlc1RvRGFzaGVzOiB0cnVlLFxuICAgICAgICBzdHJpcFB1bmN0dWF0aW9uOiB0cnVlXG4gICAgfSxcbiAgICBzaW1pbGFyaXR5VGhyZXNob2xkczoge1xuICAgICAgICBsZXZlbnNodGVpbjogMC44LFxuICAgICAgICBqYXJvV2lua2xlcjogMC44NSxcbiAgICAgICAgdG9rZW5PdmVybGFwOiAwLjdcbiAgICB9LFxuICAgIHByZXZpZXdTZXR0aW5nczoge1xuICAgICAgICBtYXhFeGFtcGxlczogNSxcbiAgICAgICAgY29udGV4dExpbmVzOiAyXG4gICAgfSxcbiAgICBzYWZlTW9kZTogdHJ1ZSxcbiAgICBlbmFibGVVbmRvOiB0cnVlLFxuICAgIG1heEJhY2t1cHM6IDEwLFxuICAgIGVuYWJsZUVtYmVkZGluZ3M6IGZhbHNlXG59O1xuIiwiaW1wb3J0IHsgUGx1Z2luLCBXb3Jrc3BhY2VMZWFmLCBURmlsZSB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IFRhZ0luZGV4ZXIgfSBmcm9tICcuL3NyYy9jb3JlL1RhZ0luZGV4ZXInO1xuaW1wb3J0IHsgVGFnTWFzdGVyU2V0dGluZ3NUYWIgfSBmcm9tICcuL3NyYy91aS9TZXR0aW5nc1RhYic7XG5pbXBvcnQgeyBUYWdNYXN0ZXJWaWV3IH0gZnJvbSAnLi9zcmMvdWkvVGFnTWFzdGVyVmlldyc7XG5pbXBvcnQgeyBUQUdNQVNURVJfVklFV19UWVBFIH0gZnJvbSAnLi9zcmMvY29uc3RhbnRzJztcbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIHR5cGUgVGFnTWFzdGVyU2V0dGluZ3MgfSBmcm9tICcuL3NyYy90eXBlcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFRhZ01hc3RlclBsdWdpbiBleHRlbmRzIFBsdWdpbiB7XG4gICAgc2V0dGluZ3M6IFRhZ01hc3RlclNldHRpbmdzO1xuICAgIGluZGV4ZXI6IFRhZ0luZGV4ZXI7XG5cbiAgICBhc3luYyBvbmxvYWQoKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdMb2FkaW5nIFRhZ01hc3RlciBQbHVnaW4nKTtcblxuICAgICAgICBhd2FpdCB0aGlzLmxvYWRTZXR0aW5ncygpO1xuXG4gICAgICAgIHRoaXMuaW5kZXhlciA9IG5ldyBUYWdJbmRleGVyKFxuICAgICAgICAgICAgdGhpcy5hcHAudmF1bHQsXG4gICAgICAgICAgICB0aGlzLmFwcC5tZXRhZGF0YUNhY2hlLFxuICAgICAgICAgICAgdGhpcy5zZXR0aW5nc1xuICAgICAgICApO1xuXG4gICAgICAgIC8vIFJlZ2lzdGVyIHZpZXdcbiAgICAgICAgdGhpcy5yZWdpc3RlclZpZXcoXG4gICAgICAgICAgICBUQUdNQVNURVJfVklFV19UWVBFLFxuICAgICAgICAgICAgKGxlYWY6IFdvcmtzcGFjZUxlYWYpID0+IG5ldyBUYWdNYXN0ZXJWaWV3KGxlYWYsIHRoaXMpXG4gICAgICAgICk7XG5cbiAgICAgICAgLy8gQWRkIHJpYmJvbiBpY29uXG4gICAgICAgIHRoaXMuYWRkUmliYm9uSWNvbigndGFncycsICdPcGVuIFRhZ01hc3RlcicsICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuYWN0aXZhdGVWaWV3KCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFJlZ2lzdGVyIGNvbW1hbmRzXG4gICAgICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICAgICAgICBpZDogJ3NjYW4tdmF1bHQnLFxuICAgICAgICAgICAgbmFtZTogJ1NjYW4gdmF1bHQgZm9yIHRhZ3MnLFxuICAgICAgICAgICAgY2FsbGJhY2s6IGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgICAgICBhd2FpdCB0aGlzLmluZGV4ZXIuaW5kZXhWYXVsdCgoY3VycmVudCwgdG90YWwpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coYEluZGV4aW5nOiAke2N1cnJlbnR9LyR7dG90YWx9YCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coYFRhZ01hc3RlcjogSW5kZXhlZCAke3RoaXMuaW5kZXhlci5nZXRUYWdDb3VudCgpfSB0YWdzYCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuYWRkQ29tbWFuZCh7XG4gICAgICAgICAgICBpZDogJ29wZW4tdGFnbWFzdGVyJyxcbiAgICAgICAgICAgIG5hbWU6ICdPcGVuIFRhZ01hc3RlciBwYW5lbCcsXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZhdGVWaWV3KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIFNldHRpbmdzIHRhYlxuICAgICAgICB0aGlzLmFkZFNldHRpbmdUYWIobmV3IFRhZ01hc3RlclNldHRpbmdzVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG5cbiAgICAgICAgLy8gRmlsZSBldmVudCBsaXN0ZW5lcnMgZm9yIGluY3JlbWVudGFsIGluZGV4aW5nXG4gICAgICAgIHRoaXMucmVnaXN0ZXJFdmVudChcbiAgICAgICAgICAgIHRoaXMuYXBwLnZhdWx0Lm9uKCdtb2RpZnknLCAoZmlsZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWxlIGluc3RhbmNlb2YgVEZpbGUgJiYgZmlsZS5leHRlbnNpb24gPT09ICdtZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbmRleGVyLmluZGV4RmlsZShmaWxlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICApO1xuXG4gICAgICAgIHRoaXMucmVnaXN0ZXJFdmVudChcbiAgICAgICAgICAgIHRoaXMuYXBwLnZhdWx0Lm9uKCdkZWxldGUnLCAoZmlsZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWxlIGluc3RhbmNlb2YgVEZpbGUgJiYgZmlsZS5leHRlbnNpb24gPT09ICdtZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pbmRleGVyLnJlbW92ZUZpbGVGcm9tSW5kZXgoZmlsZS5wYXRoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuICAgICAgICApO1xuXG4gICAgICAgIC8vIEluaXRpYWwgc2NhblxuICAgICAgICBhd2FpdCB0aGlzLmluZGV4ZXIuaW5kZXhWYXVsdCgpO1xuICAgIH1cblxuICAgIGFzeW5jIGFjdGl2YXRlVmlldygpIHtcbiAgICAgICAgdGhpcy5hcHAud29ya3NwYWNlLmRldGFjaExlYXZlc09mVHlwZShUQUdNQVNURVJfVklFV19UWVBFKTtcblxuICAgICAgICBjb25zdCBsZWFmID0gdGhpcy5hcHAud29ya3NwYWNlLmdldFJpZ2h0TGVhZihmYWxzZSk7XG4gICAgICAgIGlmIChsZWFmKSB7XG4gICAgICAgICAgICBhd2FpdCBsZWFmLnNldFZpZXdTdGF0ZSh7XG4gICAgICAgICAgICAgICAgdHlwZTogVEFHTUFTVEVSX1ZJRVdfVFlQRSxcbiAgICAgICAgICAgICAgICBhY3RpdmU6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5hcHAud29ya3NwYWNlLnJldmVhbExlYWYobGVhZik7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvbnVubG9hZCgpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1VubG9hZGluZyBUYWdNYXN0ZXIgUGx1Z2luJyk7XG4gICAgICAgIHRoaXMuYXBwLndvcmtzcGFjZS5kZXRhY2hMZWF2ZXNPZlR5cGUoVEFHTUFTVEVSX1ZJRVdfVFlQRSk7XG4gICAgfVxuXG4gICAgYXN5bmMgbG9hZFNldHRpbmdzKCkge1xuICAgICAgICB0aGlzLnNldHRpbmdzID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9TRVRUSU5HUywgYXdhaXQgdGhpcy5sb2FkRGF0YSgpKTtcbiAgICB9XG5cbiAgICBhc3luYyBzYXZlU2V0dGluZ3MoKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuc2F2ZURhdGEodGhpcy5zZXR0aW5ncyk7XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbIlBsdWdpblNldHRpbmdUYWIiLCJTZXR0aW5nIiwiSXRlbVZpZXciLCJQbHVnaW4iLCJURmlsZSJdLCJtYXBwaW5ncyI6Ijs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBa0dBO0FBQ08sU0FBUyxTQUFTLENBQUMsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDLEVBQUUsU0FBUyxFQUFFO0FBQzdELElBQUksU0FBUyxLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsT0FBTyxLQUFLLFlBQVksQ0FBQyxHQUFHLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQyxVQUFVLE9BQU8sRUFBRSxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoSCxJQUFJLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU8sQ0FBQyxFQUFFLFVBQVUsT0FBTyxFQUFFLE1BQU0sRUFBRTtBQUMvRCxRQUFRLFNBQVMsU0FBUyxDQUFDLEtBQUssRUFBRSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkcsUUFBUSxTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEcsUUFBUSxTQUFTLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxNQUFNLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0SCxRQUFRLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxVQUFVLElBQUksRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztBQUM5RSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQTZNRDtBQUN1QixPQUFPLGVBQWUsS0FBSyxVQUFVLEdBQUcsZUFBZSxHQUFHLFVBQVUsS0FBSyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDdkgsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQixJQUFJLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLFVBQVUsRUFBRSxDQUFDLENBQUM7QUFDckY7O0FDM1VPLE1BQU0sbUJBQW1CLEdBQUcsZ0JBQWdCO0FBRzVDLE1BQU0saUJBQWlCLEdBQUcscUVBQXFFOztNQ0V6RixVQUFVLENBQUE7QUFPbkIsSUFBQSxXQUFBLENBQVksS0FBWSxFQUFFLGFBQTRCLEVBQUUsUUFBMkIsRUFBQTtRQUYzRSxJQUFBLENBQUEsVUFBVSxHQUFZLEtBQUs7QUFHL0IsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDbEIsUUFBQSxJQUFJLENBQUMsYUFBYSxHQUFHLGFBQWE7QUFDbEMsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVE7QUFDeEIsUUFBQSxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksR0FBRyxFQUFFO0lBQy9CO0FBRU0sSUFBQSxVQUFVLENBQUMsVUFBcUQsRUFBQTs7QUFDbEUsWUFBQSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDakIsZ0JBQUEsT0FBTyxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQztnQkFDdkQ7WUFDSjtBQUVBLFlBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJO0FBQ3RCLFlBQUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUU7WUFFdkIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRTtBQUMzQyxZQUFBLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxNQUFNO0FBRTFCLFlBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUM1QixnQkFBQSxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLGdCQUFBLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7Z0JBRTFCLElBQUksVUFBVSxFQUFFO0FBQ1osb0JBQUEsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDO2dCQUM1QjtZQUNKO0FBRUEsWUFBQSxJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUs7UUFDM0IsQ0FBQyxDQUFBO0FBQUEsSUFBQTtBQUVLLElBQUEsU0FBUyxDQUFDLElBQVcsRUFBQTs7O1lBQ3ZCLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO1lBQ2pELE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDOztBQUdqQyxZQUFBLE1BQU0sV0FBVyxHQUFHLENBQUEsRUFBQSxHQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsTUFBQSxHQUFBLE1BQUEsR0FBQSxFQUFBLENBQUUsV0FBVztZQUN0RSxJQUFJLFdBQVcsYUFBWCxXQUFXLEtBQUEsTUFBQSxHQUFBLE1BQUEsR0FBWCxXQUFXLENBQUUsSUFBSSxFQUFFO2dCQUNuQixJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO1lBQzlEOztZQUdBLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxLQUFJO2dCQUMvQixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDO0FBQ2hELFlBQUEsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFBO0FBQUEsSUFBQTtBQUVPLElBQUEsb0JBQW9CLENBQUMsSUFBVyxFQUFFLElBQXVCLEVBQUUsT0FBZSxFQUFBO0FBQzlFLFFBQUEsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDcEQsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFFakMsUUFBQSxRQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBRztBQUNuQixZQUFBLE1BQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUEsQ0FBQSxFQUFJLEdBQUcsRUFBRTs7WUFHdEQsSUFBSSxVQUFVLEdBQUcsQ0FBQztBQUNsQixZQUFBLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNuQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ3hCLFVBQVUsR0FBRyxDQUFDO29CQUNkO2dCQUNKO1lBQ0o7QUFFQSxZQUFBLE1BQU0sVUFBVSxHQUFrQjtnQkFDOUIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO0FBQ2YsZ0JBQUEsSUFBSSxFQUFFLFVBQVU7QUFDaEIsZ0JBQUEsT0FBTyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFO0FBQ2hDLGdCQUFBLGFBQWEsRUFBRSxJQUFJO0FBQ25CLGdCQUFBLFVBQVUsRUFBRSxDQUFDO2dCQUNiLFFBQVEsRUFBRSxHQUFHLENBQUM7YUFDakI7QUFFRCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLFVBQVUsQ0FBQztBQUM1QyxRQUFBLENBQUMsQ0FBQztJQUNOO0FBRVEsSUFBQSxlQUFlLENBQUMsSUFBVyxFQUFFLElBQVksRUFBRSxVQUFrQixFQUFBO1FBQ2pFLE1BQU0sT0FBTyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFFckQsUUFBQSxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssSUFBRztBQUNwQixZQUFBLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNWLE1BQU0sR0FBRyxHQUFHLENBQUEsQ0FBQSxFQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUMxQixnQkFBQSxNQUFNLFVBQVUsR0FBa0I7b0JBQzlCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtBQUNmLG9CQUFBLElBQUksRUFBRSxVQUFVO0FBQ2hCLG9CQUFBLE9BQU8sRUFBRSxJQUFJO0FBQ2Isb0JBQUEsYUFBYSxFQUFFLEtBQUs7QUFDcEIsb0JBQUEsVUFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQztvQkFDNUIsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDO2lCQUN0QztBQUVELGdCQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQztZQUN2QztBQUNKLFFBQUEsQ0FBQyxDQUFDO0lBQ047SUFFUSxhQUFhLENBQUMsR0FBVyxFQUFFLFVBQXlCLEVBQUE7UUFDeEQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7UUFFNUMsSUFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDVixZQUFBLE9BQU8sR0FBRztnQkFDTixHQUFHO2dCQUNILGFBQWE7QUFDYixnQkFBQSxLQUFLLEVBQUUsQ0FBQztBQUNSLGdCQUFBLFdBQVcsRUFBRTthQUNoQjtZQUNELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7UUFDckM7QUFFQSxRQUFBLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNwQyxPQUFPLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsTUFBTTtJQUM5QztBQUVRLElBQUEsWUFBWSxDQUFDLEdBQVcsRUFBQTtBQUM1QixRQUFBLElBQUksVUFBVSxHQUFHLEdBQUcsQ0FBQyxXQUFXLEVBQUU7UUFFbEMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixFQUFFO0FBQ25ELFlBQUEsVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUFFLEVBQUUsQ0FBQztRQUM1RTtRQUVBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsRUFBRTtZQUN0RCxVQUFVLEdBQUcsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO1FBQzlDO1FBRUEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixFQUFFO1lBQ25ELFVBQVUsR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxFQUFFLENBQUM7UUFDdkQ7QUFFQSxRQUFBLE9BQU8sVUFBVTtJQUNyQjtJQUVBLFVBQVUsR0FBQTtRQUNOLE9BQU8sSUFBSSxDQUFDLFVBQVU7SUFDMUI7QUFFQSxJQUFBLFVBQVUsQ0FBQyxHQUFXLEVBQUE7UUFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDbkM7SUFFQSxVQUFVLEdBQUE7UUFDTixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztJQUM3QztJQUVBLFdBQVcsR0FBQTtBQUNQLFFBQUEsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUk7SUFDL0I7QUFFQSxJQUFBLG1CQUFtQixDQUFDLFFBQWdCLEVBQUE7QUFDaEMsUUFBQSxLQUFLLE1BQU0sQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsRUFBRTtBQUNqRCxZQUFBLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssUUFBUSxDQUFDO1lBQ3hFLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNO0FBRXBDLFlBQUEsSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLENBQUMsRUFBRTtBQUNsQixnQkFBQSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7WUFDL0I7UUFDSjtJQUNKO0FBQ0g7O0FDdktLLE1BQU8sb0JBQXFCLFNBQVFBLHlCQUFnQixDQUFBO0lBR3RELFdBQUEsQ0FBWSxHQUFRLEVBQUUsTUFBdUIsRUFBQTtBQUN6QyxRQUFBLEtBQUssQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDO0FBQ2xCLFFBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNO0lBQ3hCO0lBRUEsT0FBTyxHQUFBO0FBQ0gsUUFBQSxNQUFNLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSTtRQUM1QixXQUFXLENBQUMsS0FBSyxFQUFFO1FBRW5CLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLG9CQUFvQixFQUFFLENBQUM7O1FBRzFELFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLHFCQUFxQixFQUFFLENBQUM7UUFFM0QsSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxjQUFjO2FBQ3RCLE9BQU8sQ0FBQywwQ0FBMEM7QUFDbEQsYUFBQSxTQUFTLENBQUMsTUFBTSxJQUFJO2FBQ2hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXO0FBQzVELGFBQUEsUUFBUSxDQUFDLENBQU8sS0FBSyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxhQUFBO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLFdBQVcsR0FBRyxLQUFLO0FBQzNELFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxtQkFBbUI7YUFDM0IsT0FBTyxDQUFDLDhDQUE4QztBQUN0RCxhQUFBLFNBQVMsQ0FBQyxNQUFNLElBQUk7YUFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQjtBQUNqRSxhQUFBLFFBQVEsQ0FBQyxDQUFPLEtBQUssS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLO0FBQ2hFLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyx1QkFBdUI7YUFDL0IsT0FBTyxDQUFDLHFEQUFxRDtBQUM3RCxhQUFBLFNBQVMsQ0FBQyxNQUFNLElBQUk7YUFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQjtBQUNwRSxhQUFBLFFBQVEsQ0FBQyxDQUFPLEtBQUssS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsR0FBRyxLQUFLO0FBQ25FLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxtQkFBbUI7YUFDM0IsT0FBTyxDQUFDLDhCQUE4QjtBQUN0QyxhQUFBLFNBQVMsQ0FBQyxNQUFNLElBQUk7YUFDaEIsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQjtBQUNqRSxhQUFBLFFBQVEsQ0FBQyxDQUFPLEtBQUssS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtZQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLO0FBQ2hFLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDOztRQUdYLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLDZCQUE2QixFQUFFLENBQUM7UUFFbkUsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyx1QkFBdUI7YUFDL0IsT0FBTyxDQUFDLG9FQUFvRTtBQUM1RSxhQUFBLFNBQVMsQ0FBQyxNQUFNLElBQUk7QUFDaEIsYUFBQSxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJO2FBQ3BCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXO0FBQzlELGFBQUEsaUJBQWlCO0FBQ2pCLGFBQUEsUUFBUSxDQUFDLENBQU8sS0FBSyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxhQUFBO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsR0FBRyxLQUFLO0FBQzdELFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyx3QkFBd0I7YUFDaEMsT0FBTyxDQUFDLDhDQUE4QztBQUN0RCxhQUFBLFNBQVMsQ0FBQyxNQUFNLElBQUk7QUFDaEIsYUFBQSxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxJQUFJO2FBQ3BCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxXQUFXO0FBQzlELGFBQUEsaUJBQWlCO0FBQ2pCLGFBQUEsUUFBUSxDQUFDLENBQU8sS0FBSyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxhQUFBO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsR0FBRyxLQUFLO0FBQzdELFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDOztRQUdYLFdBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixFQUFFLENBQUM7UUFFeEQsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxzQkFBc0I7YUFDOUIsT0FBTyxDQUFDLHVDQUF1QztBQUMvQyxhQUFBLE9BQU8sQ0FBQyxJQUFJLElBQUk7QUFDWixhQUFBLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQztBQUNqRSxhQUFBLFFBQVEsQ0FBQyxDQUFPLEtBQUssS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtBQUN0QixZQUFBLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7WUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxFQUFFO2dCQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsV0FBVyxHQUFHLEdBQUc7QUFDdEQsZ0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtZQUNwQztRQUNKLENBQUMsQ0FBQSxDQUFDLENBQUM7O1FBR1gsV0FBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLENBQUM7UUFFOUMsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxXQUFXO2FBQ25CLE9BQU8sQ0FBQyx5Q0FBeUM7QUFDakQsYUFBQSxTQUFTLENBQUMsTUFBTSxJQUFJO2FBQ2hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRO0FBQ3RDLGFBQUEsUUFBUSxDQUFDLENBQU8sS0FBSyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxhQUFBO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxLQUFLO0FBQ3JDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxhQUFhO2FBQ3JCLE9BQU8sQ0FBQywyQ0FBMkM7QUFDbkQsYUFBQSxTQUFTLENBQUMsTUFBTSxJQUFJO2FBQ2hCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVO0FBQ3hDLGFBQUEsUUFBUSxDQUFDLENBQU8sS0FBSyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsTUFBQSxFQUFBLE1BQUEsRUFBQSxhQUFBO1lBQ3RCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxLQUFLO0FBQ3ZDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO1FBRVgsSUFBSUEsZ0JBQU8sQ0FBQyxXQUFXO2FBQ2xCLE9BQU8sQ0FBQyxhQUFhO2FBQ3JCLE9BQU8sQ0FBQyw0Q0FBNEM7QUFDcEQsYUFBQSxPQUFPLENBQUMsSUFBSSxJQUFJO2FBQ1osUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUM7QUFDaEQsYUFBQSxRQUFRLENBQUMsQ0FBTyxLQUFLLEtBQUksU0FBQSxDQUFBLElBQUEsRUFBQSxNQUFBLEVBQUEsTUFBQSxFQUFBLGFBQUE7QUFDdEIsWUFBQSxNQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsRUFBRTtnQkFDeEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLEdBQUc7QUFDckMsZ0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtZQUNwQztRQUNKLENBQUMsQ0FBQSxDQUFDLENBQUM7SUFDZjtBQUNIOztBQ3ZJSyxNQUFPLGFBQWMsU0FBUUMsaUJBQVEsQ0FBQTtJQUd2QyxXQUFBLENBQVksSUFBbUIsRUFBRSxNQUF1QixFQUFBO1FBQ3BELEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDWCxRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTTtJQUN4QjtJQUVBLFdBQVcsR0FBQTtBQUNQLFFBQUEsT0FBTyxtQkFBbUI7SUFDOUI7SUFFQSxjQUFjLEdBQUE7QUFDVixRQUFBLE9BQU8sV0FBVztJQUN0QjtJQUVBLE9BQU8sR0FBQTtBQUNILFFBQUEsT0FBTyxNQUFNO0lBQ2pCO0lBRU0sTUFBTSxHQUFBOztZQUNSLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUM5QyxTQUFTLENBQUMsS0FBSyxFQUFFO0FBQ2pCLFlBQUEsU0FBUyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQzs7QUFHcEMsWUFBQSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxFQUFFLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxDQUFDO1lBQ3JFLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLGFBQWEsRUFBRSxDQUFDO0FBRTlDLFlBQUEsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsRUFBRSxJQUFJLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQztBQUNwRixZQUFBLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsTUFBVyxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtBQUM1QyxnQkFBQSxVQUFVLENBQUMsUUFBUSxHQUFHLElBQUk7QUFDMUIsZ0JBQUEsVUFBVSxDQUFDLFdBQVcsR0FBRyxhQUFhO0FBRXRDLGdCQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxFQUFFLEtBQUssS0FBSTtvQkFDcEQsVUFBVSxDQUFDLFdBQVcsR0FBRyxDQUFBLFNBQUEsRUFBWSxPQUFPLENBQUEsQ0FBQSxFQUFJLEtBQUssRUFBRTtBQUMzRCxnQkFBQSxDQUFDLENBQUM7QUFFRixnQkFBQSxVQUFVLENBQUMsV0FBVyxHQUFHLFlBQVk7QUFDckMsZ0JBQUEsVUFBVSxDQUFDLFFBQVEsR0FBRyxLQUFLO2dCQUMzQixJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3hCLENBQUMsQ0FBQSxDQUFDOztBQUdGLFlBQUEsTUFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQztBQUNuRSxZQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDOztBQUd2QixZQUFBLE1BQU0sYUFBYSxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEVBQUUsR0FBRyxFQUFFLGdCQUFnQixFQUFFLENBQUM7QUFDMUUsWUFBQSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQztRQUNyQyxDQUFDLENBQUE7QUFBQSxJQUFBO0FBRU8sSUFBQSxXQUFXLENBQUMsU0FBc0IsRUFBQTtRQUN0QyxTQUFTLENBQUMsS0FBSyxFQUFFO1FBQ2pCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRTtBQUNsRCxRQUFBLFNBQVMsQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUEsWUFBQSxFQUFlLFFBQVEsQ0FBQSxDQUFFLEVBQUUsQ0FBQztJQUNoRTtBQUVRLElBQUEsYUFBYSxDQUFDLFNBQXVCLEVBQUE7QUFDekMsUUFBQSxNQUFNLE1BQU0sR0FBRyxTQUFTLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUM7QUFDN0UsUUFBQSxJQUFJLENBQUMsTUFBTTtZQUFFO1FBRWIsTUFBTSxDQUFDLEtBQUssRUFBRTtRQUVkLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtRQUNoRCxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7YUFDMUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFFNUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFJO0FBQy9CLFlBQUEsTUFBTSxPQUFPLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsRUFBRSxHQUFHLEVBQUUsb0JBQW9CLEVBQUUsQ0FBQztBQUVyRSxZQUFnQixPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRTtBQUNyQyxnQkFBQSxHQUFHLEVBQUUsb0JBQW9CO0FBQ3pCLGdCQUFBLElBQUksRUFBRTtBQUNULGFBQUE7QUFFRCxZQUFpQixPQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRTtBQUN0QyxnQkFBQSxHQUFHLEVBQUUscUJBQXFCO0FBQzFCLGdCQUFBLElBQUksRUFBRSxDQUFBLEVBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQTtBQUN0QixhQUFBO0FBRUQsWUFBQSxPQUFPLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE1BQUs7QUFDbkMsZ0JBQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO0FBQ2xDLFlBQUEsQ0FBQyxDQUFDO0FBQ04sUUFBQSxDQUFDLENBQUM7O1FBR0YsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7UUFDbEUsSUFBSSxPQUFPLEVBQUU7QUFDVCxZQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBc0IsQ0FBQztRQUM1QztJQUNKO0lBRVEsY0FBYyxDQUFDLEdBQVcsRUFBRSxJQUFTLEVBQUE7UUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQzs7SUFFMUM7SUFFTSxPQUFPLEdBQUE7OztRQUViLENBQUMsQ0FBQTtBQUFBLElBQUE7QUFDSjs7QUNsQ00sTUFBTSxnQkFBZ0IsR0FBc0I7QUFDL0MsSUFBQSxrQkFBa0IsRUFBRTtBQUNoQixRQUFBLFdBQVcsRUFBRSxJQUFJO0FBQ2pCLFFBQUEsZ0JBQWdCLEVBQUUsSUFBSTtBQUN0QixRQUFBLG1CQUFtQixFQUFFLElBQUk7QUFDekIsUUFBQSxnQkFBZ0IsRUFBRTtBQUNyQixLQUFBO0FBQ0QsSUFBQSxvQkFBb0IsRUFBRTtBQUNsQixRQUFBLFdBQVcsRUFBRSxHQUFHO0FBQ2hCLFFBQUEsV0FBVyxFQUFFLElBQUk7QUFDakIsUUFBQSxZQUFZLEVBQUU7QUFDakIsS0FBQTtBQUNELElBQUEsZUFBZSxFQUFFO0FBQ2IsUUFBQSxXQUFXLEVBQUUsQ0FBQztBQUNkLFFBQUEsWUFBWSxFQUFFO0FBQ2pCLEtBQUE7QUFDRCxJQUFBLFFBQVEsRUFBRSxJQUFJO0FBQ2QsSUFBQSxVQUFVLEVBQUUsSUFBSTtBQUNoQixJQUFBLFVBQVUsRUFBRSxFQUFFO0FBQ2QsSUFBQSxnQkFBZ0IsRUFBRTtDQUNyQjs7QUNwRmEsTUFBTyxlQUFnQixTQUFRQyxlQUFNLENBQUE7SUFJekMsTUFBTSxHQUFBOztBQUNSLFlBQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQztBQUV2QyxZQUFBLE1BQU0sSUFBSSxDQUFDLFlBQVksRUFBRTtZQUV6QixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksVUFBVSxDQUN6QixJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFDdEIsSUFBSSxDQUFDLFFBQVEsQ0FDaEI7O0FBR0QsWUFBQSxJQUFJLENBQUMsWUFBWSxDQUNiLG1CQUFtQixFQUNuQixDQUFDLElBQW1CLEtBQUssSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUN6RDs7WUFHRCxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxNQUFLO2dCQUM5QyxJQUFJLENBQUMsWUFBWSxFQUFFO0FBQ3ZCLFlBQUEsQ0FBQyxDQUFDOztZQUdGLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDWixnQkFBQSxFQUFFLEVBQUUsWUFBWTtBQUNoQixnQkFBQSxJQUFJLEVBQUUscUJBQXFCO2dCQUMzQixRQUFRLEVBQUUsTUFBVyxTQUFBLENBQUEsSUFBQSxFQUFBLE1BQUEsRUFBQSxNQUFBLEVBQUEsYUFBQTtvQkFDakIsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxLQUFLLEtBQUk7d0JBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSxVQUFBLEVBQWEsT0FBTyxDQUFBLENBQUEsRUFBSSxLQUFLLENBQUEsQ0FBRSxDQUFDO0FBQ2hELG9CQUFBLENBQUMsQ0FBQztBQUNGLG9CQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQSxtQkFBQSxFQUFzQixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFBLEtBQUEsQ0FBTyxDQUFDO0FBQ3hFLGdCQUFBLENBQUM7QUFDSixhQUFBLENBQUM7WUFFRixJQUFJLENBQUMsVUFBVSxDQUFDO0FBQ1osZ0JBQUEsRUFBRSxFQUFFLGdCQUFnQjtBQUNwQixnQkFBQSxJQUFJLEVBQUUsc0JBQXNCO2dCQUM1QixRQUFRLEVBQUUsTUFBSztvQkFDWCxJQUFJLENBQUMsWUFBWSxFQUFFO2dCQUN2QjtBQUNILGFBQUEsQ0FBQzs7QUFHRixZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDOztBQUc1RCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksS0FBSTtnQkFDakMsSUFBSSxJQUFJLFlBQVlDLGNBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksRUFBRTtBQUNsRCxvQkFBQSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7Z0JBQ2hDO1lBQ0osQ0FBQyxDQUFDLENBQ0w7QUFFRCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQ2QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksS0FBSTtnQkFDakMsSUFBSSxJQUFJLFlBQVlBLGNBQUssSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksRUFBRTtvQkFDbEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO2dCQUMvQztZQUNKLENBQUMsQ0FBQyxDQUNMOztBQUdELFlBQUEsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtRQUNuQyxDQUFDLENBQUE7QUFBQSxJQUFBO0lBRUssWUFBWSxHQUFBOztZQUNkLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDO0FBRTFELFlBQUEsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztZQUNuRCxJQUFJLElBQUksRUFBRTtnQkFDTixNQUFNLElBQUksQ0FBQyxZQUFZLENBQUM7QUFDcEIsb0JBQUEsSUFBSSxFQUFFLG1CQUFtQjtBQUN6QixvQkFBQSxNQUFNLEVBQUU7QUFDWCxpQkFBQSxDQUFDO2dCQUNGLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDdkM7UUFDSixDQUFDLENBQUE7QUFBQSxJQUFBO0lBRUQsUUFBUSxHQUFBO0FBQ0osUUFBQSxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDO1FBQ3pDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLG1CQUFtQixDQUFDO0lBQzlEO0lBRU0sWUFBWSxHQUFBOztBQUNkLFlBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5RSxDQUFDLENBQUE7QUFBQSxJQUFBO0lBRUssWUFBWSxHQUFBOztZQUNkLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ3RDLENBQUMsQ0FBQTtBQUFBLElBQUE7QUFDSjs7OzsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19
